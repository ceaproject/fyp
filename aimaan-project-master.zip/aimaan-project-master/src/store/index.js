import {
  configureStore,
  combineReducers,
  applyMiddleware,
  createStore,
  getDefaultMiddleware,
} from '@reduxjs/toolkit';
import { authSlice, usersSlice, eventsSlice, chatsSlice } from './slices';
import { composeWithDevTools } from '@redux-devtools/extension';

import createSocketIoMiddleware from 'redux-socket.io';
import io from 'socket.io-client';
import { baseOrigin } from 'api';
import { newMessage } from './slices/chats';
import thunk from 'redux-thunk';

function optimisticExecute(action, emit, next, dispatch) {
  emit('action', action);
  next(action);
}

const socket = io.connect(baseOrigin, {
  transports: ['websocket'],
});

socket.on('connect', (socket) => {
  console.log('connected', socket);
});
const socketIoMiddleware = createSocketIoMiddleware(socket, 'chats/', {
  execute: optimisticExecute,
});

let reducer = combineReducers({
  auth: authSlice.reducer,
  users: usersSlice.reducer,
  events: eventsSlice.reducer,
  chats: chatsSlice.reducer,
});

const store = createStore(
  reducer,
  composeWithDevTools(
    applyMiddleware(thunk, socketIoMiddleware)
    // other store enhancers if any
  )
);

export default store;

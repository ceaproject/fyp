import { createSlice } from '@reduxjs/toolkit';
import { TOKEN_KEY } from 'api';
import { toast } from 'react-toastify';
import { getMyBookings } from '../users/extraReducers';
import {
  getMe,
  login,
  updateMe,
  signUp,
  updatePassword,
} from './extraReducers';

const initialState = {
  authenticating: true,
  user: null,
  bookings: [],
  token: localStorage.getItem(TOKEN_KEY) || null,
  loading: false,
  isLoggedIn: false,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    logout: (state) => {
      state.isLoggedIn = false;
      state.user = null;
      state.token = null;
      localStorage.removeItem(TOKEN_KEY);
    },
    addBooking: (state, action) => {
      console.log('action.payload', action.payload);
      state.bookings = [...state.bookings, action.payload];
    },
    removeBooking: (state, action) => {
      state.bookings = state.bookings.filter((el) => el._id !== action.payload);
    },
  },
  extraReducers: {
    [getMe.pending]: (state, { payload }) => {
      state.authenticating = true;
    },
    [getMe.fulfilled]: (state, { payload }) => ({
      authenticating: false,
      token: payload.token,
      user: payload.user,
      isLoggedIn: true,
    }),
    [getMe.rejected]: (state, { payload }) => {
      state.authenticating = false;
    },
    [getMyBookings.pending]: (state, { payload }) => {
      state.loading = true;
    },
    [getMyBookings.fulfilled]: (state, { payload }) => ({
      ...state,
      loading: false,
      bookings: payload.bookings,
      isLoggedIn: true,
    }),
    [getMyBookings.rejected]: (state, { payload }) => {
      state.loading = false;
    },
    [login.pending]: (state, { payload }) => {
      state.loading = true;
    },
    [login.fulfilled]: (state, { payload }) => {
      localStorage.setItem(TOKEN_KEY, payload.token);
      return {
        token: payload.token,
        user: payload.user,
        isLoggedIn: true,
        loading: false,
        authenticating: false,
      };
    },
    [login.rejected]: (state, { payload }) => {
      state.loading = false;
    },

    [signUp.pending]: (state, { payload }) => {
      state.loading = true;
    },
    [signUp.fulfilled]: (state, { payload }) => {
      localStorage.setItem(TOKEN_KEY, payload.token);
      return {
        token: payload.token,
        user: payload.user,
        isLoggedIn: true,
        loading: false,
        authenticating: false,
      };
    },
    [signUp.rejected]: (state, { payload }) => {
      state.loading = false;
    },

    [updateMe.pending]: (state, { payload }) => {
      state.loading = true;
    },
    [updateMe.fulfilled]: (state, { payload }) => ({
      ...state,
      user: payload.user,
      isLoggedIn: true,
    }),
    [updateMe.rejected]: (state, { payload }) => {
      state.loading = false;
    },
    [updatePassword.pending]: (state, { payload }) => {
      state.loading = true;
    },
    [updatePassword.fulfilled]: (state, { payload }) => ({
      ...state,
      user: payload.user,
      isLoggedIn: true,
    }),
  },
});

export const { logout, addBooking, removeBooking } = authSlice.actions;
export default authSlice;

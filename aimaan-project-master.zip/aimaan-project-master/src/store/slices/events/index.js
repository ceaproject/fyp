import { createSlice } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import {
  cancelEvent,
  createEvent,
  deleteEvent,
  getAllEvents,
  handleBooking,
  registerEvent,
  updateEvent,
  updateStatus,
} from './extraReducers';

const initialState = {
  fetching: false,
  loading: false,
  events: undefined,
};

const eventsSlice = createSlice({
  name: 'events',
  initialState,
  reducers: {},
  extraReducers: {
    [getAllEvents.pending]: (state) => {
      state.fetching = true;
    },
    [getAllEvents.fulfilled]: (state, { payload }) => ({
      ...state,
      fetching: false,
      events: payload.events,
    }),
    [getAllEvents.rejected]: (state) => ({
      ...state,
      fetching: false,
      events: [],
    }),

    [createEvent.pending]: (state) => {
      state.loading = true;
    },
    [createEvent.fulfilled]: (state, { payload }) => {
      toast.success('Event Created Successfully!');
      console.log('Date.now()', Date.now());
      console.log('payload', payload);

      state.loading = false;
      state.events = state.events
        ? [...state.events, payload.event]
        : [payload.event];
    },
    [createEvent.rejected]: (state) => {
      state.loading = false;
    },

    [handleBooking.pending]: (state) => {
      state.loading = true;
    },
    [handleBooking.fulfilled]: (state, { payload }) => ({
      ...state,
      loading: false,
      events: state.events.map((el) =>
        el._id === payload.event._id ? payload.event : el
      ),
    }),
    [handleBooking.rejected]: (state) => {
      state.loading = false;
    },

    [updateEvent.pending]: (state) => {
      state.loading = true;
    },
    [updateEvent.fulfilled]: (state, { payload }) => ({
      ...state,
      loading: false,
      events: state.events.map((el) =>
        el._id === payload.event._id ? payload.event : el
      ),
    }),
    [updateEvent.rejected]: (state) => {
      state.loading = false;
    },

    [updateStatus.pending]: (state) => {
      state.loading = true;
    },
    [updateStatus.fulfilled]: (state, { payload }) => ({
      ...state,
      loading: false,
      events: state.events.map((el) =>
        el._id === payload.event._id ? payload.event : el
      ),
    }),
    [updateStatus.rejected]: (state) => {
      state.loading = false;
    },

    [deleteEvent.pending]: (state) => {
      state.loading = true;
    },
    [deleteEvent.fulfilled]: (state, { payload }) => {
      state.loading = false;
      state.events = state.events.filter((el) => el._id !== payload.event._id);
      toast.success('Event Deleted Successfully!');
    },
    [deleteEvent.rejected]: (state) => {
      state.loading = false;
    },

    [registerEvent.pending]: (state) => {
      state.loading = true;
    },
    [registerEvent.fulfilled]: (state, { payload }) => {
      state.loading = false;
      state.events = state.events.map((el) =>
        el._id === payload.event._id ? payload.event : el
      );
      toast.success('Event Registered Successfully!');
    },
    [registerEvent.rejected]: (state) => {
      state.loading = false;
    },

    [cancelEvent.pending]: (state) => {
      state.loading = true;
    },
    [cancelEvent.fulfilled]: (state, { payload }) => {
      state.loading = false;
      toast.success('Event Booking Cancelled!');
      state.events = state.events.map((el) =>
        el._id === payload.event._id ? payload.event : el
      );
    },
    [cancelEvent.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export default eventsSlice;

import { createAsyncThunk } from '@reduxjs/toolkit';
import * as eventsApi from 'api/events';
import { toast } from 'react-toastify';

export const getAllEvents = createAsyncThunk(
  '/events/getAll',
  async (_, { rejectWithValue }) => {
    return eventsApi
      .getAll()
      .then((res) => ({ events: res.data.events }))
      .catch((err) => {
        return rejectWithValue(err);
      });
  }
);

export const createEvent = createAsyncThunk(
  '/events/createOne',
  async (createdEvent, { rejectWithValue }) =>
    eventsApi
      .createOne(createdEvent)
      .then((res) => ({ event: res.event }))
      .catch((err) => {
        toast.error(err);
        return rejectWithValue(err);
      })
);

export const handleBooking = createAsyncThunk(
  '/events/handleBooking',
  async ({ id, updatedEvent }, { rejectWithValue }) => {
    return eventsApi
      .handleBooking({ id, updatedEvent })
      .then((res) => ({ event: res.data.event }))
      .catch((err) => {
        toast.error(err);
        return rejectWithValue(err);
      });
  }
);

export const registerEvent = createAsyncThunk(
  '/events/registerEvent',
  async (id, { rejectWithValue }) => {
    return eventsApi
      .registerEvent(id)
      .then((res) => ({ booking: res.data.booking, event: res.data.event }))
      .catch((err) => {
        toast.error(err);
        return rejectWithValue(err);
      });
  }
);

export const cancelEvent = createAsyncThunk(
  '/events/cancelEvent',
  async (id, { rejectWithValue }) => {
    return eventsApi
      .cancelEvent(id)
      .then((res) => ({ booking: res.data.booking, event: res.data.event }))
      .catch((err) => {
        toast.error(err);
        return rejectWithValue(err);
      });
  }
);

export const deleteEvent = createAsyncThunk(
  '/events/deleteOne',
  async (id, { rejectWithValue }) => {
    return eventsApi
      .deleteOne(id)
      .then((res) => ({ event: res.data.event }))
      .catch((err) => {
        toast.error(err);
        return rejectWithValue(err);
      });
  }
);

export const updateEvent = createAsyncThunk(
  '/events/updateOne',
  async ({ id, updatedEvent }, { rejectWithValue }) => {
    return eventsApi
      .updateOne(id, updatedEvent)
      .then((res) => ({ event: res.data.event }))
      .catch((err) => {
        toast.error(err);
        return rejectWithValue(err);
      });
  }
);

export const updateStatus = createAsyncThunk(
  '/events/updateStatus',
  async ({ id, status }, { rejectWithValue }) => {
    return eventsApi
      .updateStatus(id, status)
      .then((res) => ({ event: res.data.event }))
      .catch((err) => {
        toast.error(err);
        return rejectWithValue(err);
      });
  }
);

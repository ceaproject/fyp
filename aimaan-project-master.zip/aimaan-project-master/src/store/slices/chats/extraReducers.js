import { createAsyncThunk } from '@reduxjs/toolkit';
import * as chatApi from 'api/chats';
import { toast } from 'react-toastify';

export const getAllChats = createAsyncThunk(
  '/chats/getAll',
  async (_, { rejectWithValue }) => {
    return chatApi
      .getAll()
      .then((res) => ({ chats: res.data.chats }))
      .catch((err) => {
        return rejectWithValue(err);
      });
  }
);

export const createNewChat = createAsyncThunk(
  '/chats/createNew',
  async (id, { rejectWithValue }) => {
    return chatApi
      .createNew(id)
      .then((res) => ({ chat: res.data.chat }))
      .catch((err) => {
        return rejectWithValue(err);
      });
  }
);

export const deleteChat = createAsyncThunk(
  '/chats/deleteOne',
  async (id, { rejectWithValue }) => {
    return chatApi
      .deleteOne(id)
      .then((res) => ({ chat: res.data.chat }))
      .catch((err) => {
        toast.error(err);
        return rejectWithValue(err);
      });
  }
);

import { createSlice } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import { createNewChat, deleteChat, getAllChats } from './extraReducers';
import { store } from 'index';

const initialState = {
  sending: false,
  loading: true,
  fetching: true,
  chats: [],
  activeChat: null,
};

const chatsSlice = createSlice({
  name: 'chats',
  initialState,
  reducers: {
    newMessage: (state, { payload }) => {
      console.log('state', state.activeChat);
      console.log('{payload}', { payload });

      state.chats = state.chats.map((el) =>
        el.participants.find((el) => el._id === payload.userId) &&
        el._id === payload.chatId
          ? {
              ...el,
              messages: [...el.messages, payload.message],
            }
          : el
      );
      if (state.activeChat)
        state.activeChat = state.chats.find(
          (el) => el._id === state.activeChat._id
        );

      state.loading = false;
    },
    sendMessage: (state) => {
      state.loading = true;
    },
    setActiveChat: (state, action) => {
      state.activeChat = action.payload;
    },
  },
  extraReducers: {
    [getAllChats.pending]: (state) => {
      state.fetching = true;
    },
    [getAllChats.fulfilled]: (state, { payload }) => {
      console.log('payload', payload);
      return {
        ...state,
        fetching: false,
        chats: payload.chats,
        activeChat: payload.chats[0],
      };
    },
    [getAllChats.rejected]: (state) => ({
      ...state,
      fetching: false,
      chats: [],
    }),

    [createNewChat.pending]: (state) => {
      state.loading = true;
    },
    [createNewChat.fulfilled]: (state, { payload }) => {
      state.loading = false;
      state.chats = [...state.chats, payload.chat];
    },
    [createNewChat.rejected]: (state) => ({
      ...state,
      loading: false,
      chats: [],
    }),

    [deleteChat.pending]: (state) => {
      state.loading = true;
    },
    [deleteChat.fulfilled]: (state, { payload }) => {
      state.loading = false;
      state.chats = state.chats.filter((el) => el._id !== payload.chat._id);
      toast.success('Chat Deleted Successfully!');
    },
    [deleteChat.rejected]: (state) => ({
      ...state,
      loading: false,
      chats: [],
    }),
  },
});

export const { newMessage, setActiveChat } = chatsSlice.actions;
export default chatsSlice;

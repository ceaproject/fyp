import { createAsyncThunk } from '@reduxjs/toolkit';
import * as userApi from 'api/users';
import { toast } from 'react-toastify';

export const getAllUsers = createAsyncThunk(
  '/users/getAll',
  async (_, { rejectWithValue }) => {
    return userApi
      .getAll()
      .then((res) => ({ users: res.data.users }))
      .catch((err) => {
        return rejectWithValue(err);
      });
  }
);

export const getMyBookings = createAsyncThunk(
  '/users/getMyBookings',
  async (_, { rejectWithValue }) => {
    return userApi
      .getMyBookings()
      .then((res) => ({ bookings: res.data.bookings }))
      .catch((err) => {
        return rejectWithValue(err);
      });
  }
);

export const deleteUser = createAsyncThunk(
  '/users/deleteOne',
  async (id, { rejectWithValue }) => {
    return userApi
      .deleteOne(id)
      .then((res) => ({ user: res.data.user }))
      .catch((err) => {
        toast.error(err);
        return rejectWithValue(err);
      });
  }
);
export const updateUser = createAsyncThunk(
  '/users/updateOne',
  async ({ id, updatedUser }, { rejectWithValue }) => {
    return userApi
      .updateOne({ id, updatedUser })
      .then((res) => ({ user: res.data.user }))
      .catch((err) => {
        toast.error(err);
        return rejectWithValue(err);
      });
  }
);

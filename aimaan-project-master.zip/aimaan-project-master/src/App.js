import './App.css';
import { useEffect } from 'react';
import { getMe } from 'store/slices/auth/extraReducers';

import ThemeConfig from './theme';
import GlobalStyles from './theme/globalStyles';
import { useDispatch, useSelector } from 'react-redux';
import Router from 'Router';
import { getMyBookings } from 'store/slices/users/extraReducers';
import { getAllChats } from 'store/slices/chats/extraReducers';
import config from 'components/chatbot/config';
import MessageParser from 'components/chatbot/messageParser';
import ActionProvider from 'components/chatbot/actionProvider';
import Chatbot from 'components/chatbot';

function App() {
  const { authenticating } = useSelector((st) => st.auth);
  const dispatch = useDispatch();
  useEffect(() => {
    if (authenticating)
      dispatch(getMe()).then(({ err }) => {
        if (!err) dispatch(getMyBookings());

        if (!err) dispatch(getAllChats());
      });
  }, [authenticating]);

  return (
    <div>
      <ThemeConfig>
        <Chatbot />

        <GlobalStyles />
        <Router />
      </ThemeConfig>
    </div>
  );
}

export default App;

import Footer from 'components/footer/footer';
import Navbar from 'components/navbar/navbar';
import { Outlet } from 'react-router-dom';

export default function HomePageLayout({ element }) {
  return (
    <div>
      <Navbar />
      {element}
      <Footer />
    </div>
  );
}

import { Icon } from '@iconify/react';
import pieChart2Fill from '@iconify/icons-eva/pie-chart-2-fill';
import peopleFill from '@iconify/icons-eva/people-fill';
import logoutFill from '@iconify/icons-eva/log-out-fill';
// import bannersFill from '@iconify/icons-eva/camera-fill';
import personFill from '@iconify/icons-eva/person-fill';
import chatFill from '@iconify/icons-eva/message-circle-fill';
// ----------------------------------------------------------------------

const getIcon = (name) => <Icon icon={name} width={22} height={22} />;

export const adminConfig = [
  {
    title: 'dashboard',
    path: '/dashboard',
    icon: getIcon(pieChart2Fill),
  },
  {
    title: 'Profile',
    path: '/dashboard/profile',
    icon: getIcon(personFill),
  },
  {
    title: 'Users',
    path: '/dashboard/users',
    icon: getIcon(peopleFill),
  },
  {
    title: 'Messages',
    path: '/dashboard/messages',
    icon: getIcon(chatFill),
  },
  {
    title: 'Event',
    path: '/dashboard/events',
    icon: getIcon(peopleFill),
  },
  {
    title: 'Logout',
    path: '/logout',
    icon: getIcon(logoutFill),
  },
];
export const userConfig = [
  {
    title: 'dashboard',
    path: '/dashboard',
    icon: getIcon(pieChart2Fill),
  },
  {
    title: 'Profile',
    path: '/dashboard/profile',
    icon: getIcon(personFill),
  },
  {
    title: 'Members',
    path: '/dashboard/users',
    icon: getIcon(peopleFill),
  },
  {
    title: 'Event',
    path: '/dashboard/events',
    icon: getIcon(peopleFill),
  },
  {
    title: 'Logout',
    path: '/logout',
    icon: getIcon(logoutFill),
  },
];
export const managerConfig = [
  {
    title: 'dashboard',
    path: '/dashboard',
    icon: getIcon(pieChart2Fill),
  },
  {
    title: 'Profile',
    path: '/dashboard/profile',
    icon: getIcon(personFill),
  },
  {
    title: 'Messages',
    path: '/dashboard/messages',
    icon: getIcon(chatFill),
  },
  {
    title: 'Users',
    path: '/dashboard/users',
    icon: getIcon(peopleFill),
  },
  {
    title: 'Event',
    path: '/dashboard/events',
    icon: getIcon(peopleFill),
  },
  {
    title: 'Logout',
    path: '/logout',
    icon: getIcon(logoutFill),
  },
];

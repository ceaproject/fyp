import React from 'react';
import './welcome.css';
import '../../App.css';

const Welcome = () => {
  return (
    <div>
      {/* <!-- welcome section starts from here --> */}
      <div className='welcome' id='welcome'>
        <div className='top'>
          <div className='left'>
            <span>
              Welcome to our
              <h1>StarTech Agency</h1>
            </span>
          </div>
          <div className='right'>
            <h2>
              We empower you, your team and your organization to exceed your
              potential.{' '}
            </h2>
            <p>
              Established in 2022, the StarTech Institute is an innovation
              center focused on illuminating key trends and drivers of human and
              organizational performance. We develop and infuse robust
              scientific research, cutting-edge intellectual property, and
              state-of-the-art analytics into StarTech Solutions.
            </p>
          </div>
        </div>
        <div className='bottom'>
          <div className='guide'>
            <i className='fas fa-address-card'></i>
            <h1>Creative Your Profile</h1>
            <p>
              Debitis obcaecati dolore quisquam consectetur sed ea quos minima
              ducimus iusto?
            </p>
          </div>
          <div className='guide'>
            <i className='fas fa-pencil'></i>
            <h1>Apply for Auditions</h1>
            <p>
              Debitis obcaecati dolore quisquam consectetur sed ea quos minima
              ducimus iusto?
            </p>
          </div>
          <div className='guide'>
            <i className='fas fa-globe'></i>
            <h1>Get Discovered</h1>
            <p>
              Debitis obcaecati dolore quisquam consectetur sed ea quos minima
              ducimus iusto?
            </p>
          </div>
          <div className='guide'>
            <i className='fas fa-radio'></i>
            <h1>Multinational Studios</h1>
            <p>
              Debitis obcaecati dolore quisquam consectetur sed ea quos minima
              ducimus iusto?
            </p>
          </div>
        </div>
      </div>
      {/* <!-- welcome section ends here --> */}
    </div>
  );
};

export default Welcome;

import React, { useState } from 'react';
import './navbar.css';
import '../../App.css';
import { NavLink } from 'react-router-dom';
import { useSelector } from 'react-redux';

const Navbar = () => {
  const [active, setActive] = useState(false);
  const { isLoggedIn } = useSelector((st) => st.auth);
  return (
    <div>
      <div className='navbar' id='navbar'>
        <div className='left'>
          <img src='images/logo.png' alt='img' />
        </div>
        <div className='menu' onClick={() => setActive(!active)}>
          {active ? 'Close' : 'Menu'}
          {/* <i className="fas fa-bars"></i> */}
        </div>
        <div className={active ? 'right active' : 'right'}>
          <a href='#home'>Home</a>
          {isLoggedIn && <NavLink to='/dashboard'>Dashboard</NavLink>}
          <a href='#services'>services</a>
          <a href='#research'>Institute</a>
          <a href='#team'>team</a>
          <a href='#about'>about us</a>
          <a href='#newsletter'>Contact us</a>
          {isLoggedIn ? (
            <NavLink to='/logout'>Logout</NavLink>
          ) : (
            <NavLink to='/account'>login</NavLink>
          )}
        </div>
      </div>
      {/* <!-- navbar code ends here --> */}
    </div>
  );
};

export default Navbar;

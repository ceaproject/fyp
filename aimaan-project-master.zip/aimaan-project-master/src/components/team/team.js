import React from 'react';
import './team.css';
import '../../App.css';

const Team = () => {
  return (
    <div>
      {/* <!-- our team section starts from here --> */}
      <div className='team' id='team'>
        <div className='section-heading'>
          <h1>Our Team</h1>
        </div>
        <div className='content'>
          <div className='team-member'>
            <div className='img'>
              <img src='images/team1.jpg' alt='img' />
            </div>
            <div className='member-detail'>
              <p>Gray</p>
              <p>Creative Director</p>
            </div>
          </div>
          <div className='team-member'>
            <div className='img'>
              <img src='images/team4.jpg' alt='img' />
            </div>
            <div className='member-detail'>
              <p>Gray</p>
              <p>Creative Director</p>
            </div>
          </div>
          <div className='team-member'>
            <div className='img'>
              <img src='images/team3.jpg' alt='img' />
            </div>
            <div className='member-detail'>
              <p>Gray</p>
              <p>Creative Director</p>
            </div>
          </div>
          <div className='team-member'>
            <div className='img'>
              <img src='images/why-us.jpg' alt='img' />
            </div>
            <div className='member-detail'>
              <p>Gray</p>
              <p>Creative Director</p>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- our team section ends here --> */}
    </div>
  );
};

export default Team;

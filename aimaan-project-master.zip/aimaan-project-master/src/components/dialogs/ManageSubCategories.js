import { Delete } from '@mui/icons-material';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  TextField
} from '@mui/material';
import { useTextInput } from 'hooks';
import React from 'react';

const ManageSubCategories = ({ open, toggleDialog, handleAdd, handleRemove, subCategories }) => {
  const [name, handleChange, reset] = useTextInput('');

  const handleSubmit = (e) => {
    e.preventDefault();
    handleAdd(name);
    reset();
  };

  const handleDelete = (e) => {
    const { id } = e.currentTarget.dataset;
    console.log('id', id);
    handleRemove(id);
  };

  return (
    <Dialog open={open} onClose={toggleDialog}>
      <DialogTitle>Manage Sub Categories</DialogTitle>
      <DialogContent>
        <form onSubmit={handleSubmit}>
          <Typography variant="body1">Add New</Typography>
          <TextField
            label="Name"
            variant="outlined"
            fullWidth
            value={name}
            onChange={handleChange}
          />
        </form>
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: '60%' }} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell align="right">Created At</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {subCategories.map((row) => (
                <TableRow key={row.name} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                  <TableCell align="right">{row.name}</TableCell>
                  <TableCell align="right">{new Date(row.createdAt).toDateString()}</TableCell>
                  <TableCell align="right">
                    <IconButton data-id={row._id} onClick={handleDelete}>
                      <Delete />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </DialogContent>
      <DialogActions>
        <Button variant="contained" color="primary" onClick={toggleDialog}>
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ManageSubCategories;

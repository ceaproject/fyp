import React, { useState, useEffect, useContext } from 'react';
import { filter } from 'lodash';

// material
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import {
  Card,
  Table,
  Stack,
  Avatar,
  Button,
  TableRow,
  TableBody,
  TableCell,
  Typography,
  TableContainer,
  TablePagination,
  Checkbox,
  Select,
  styled,
  FormControl,
  InputLabel,
  MenuItem
} from '@mui/material';
// components
// import Skeleton from '@material-ui/lab/Skeleton';
import Skeleton from 'react-loading-skeleton';

import Scrollbar from 'components/Scrollbar';
import SearchNotFound from 'components/SearchNotFound';
import { UserListHead, UserListToolbar } from 'components/_dashboard/user';
//

const PREFIX = 'AddToTable';

const classes = {
  Dialog: `${PREFIX}-dialog`
};

const StyledBox = styled('div')(({ theme }) => ({
  [`&.${classes.Dialog}`]: {
    backgroundColor: 'red',
    '& .MuiPaper-root': {
      maxWidth: 'unset',
      width: 800
    },
    '& h2': {
      backgroundColor: 'red'
    }
  }
}));

const TABLE_HEAD = [
  { id: 'name', label: 'Name', alignRight: false },
  { id: 'questions', label: 'Questions', alignRight: false }
];

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

const AddToTableModal = (props) => {
  const { isOpen, closeDialog, targetId, data, addAction, slug, resource } = props;

  const [filteredGroups, setFilteredGroups] = useState([]);
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState('asc');
  const [selected, setSelected] = useState([]);
  const [orderBy, setOrderBy] = useState('name');
  const [filterName, setFilterName] = useState('');
  const [isDelOpen, setIsDelOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  useEffect(() => {}, [data]);

  function getComparator(order, orderBy) {
    return order === 'desc'
      ? (a, b) => descendingComparator(a, b, orderBy)
      : (a, b) => -descendingComparator(a, b, orderBy);
  }

  const handleSubmit = (e) => {
    addAction(targetId, selected);
    setSelected([]);
    closeDialog();
    e.preventDefault();
  };

  function applySortFilter(array, comparator, query) {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
      const order = comparator(a[0], b[0]);
      if (order !== 0) return order;
      return a[1] - b[1];
    });
    if (query) {
      return filter(array, (_user) => _user.name.toLowerCase().indexOf(query.toLowerCase()) !== -1);
    }
    return stabilizedThis.map((el) => el[0]);
  }

  useEffect(() => {
    console.log('selected', selected);
  }, [selected]);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelecteds = data.map((n) => n.name);
      setSelected(newSelecteds);
      return;
    }
    setSelected([]);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (event) => {
    setFilterName(event.target.value);
  };

  const emptyRows = page > 0 && data ? Math.max(0, (1 + page) * rowsPerPage - data.length) : 0;

  const isUserNotFound = filteredGroups.length === 0;

  useEffect(() => {
    if (!data || data === null) return;
    setFilteredGroups(applySortFilter(data, getComparator(order, orderBy), filterName));
  }, [data, order, orderBy, filterName]);

  const isAlreadyHere = (target, array) => {
    if (resource === 'Employee') {
      const condition = !!array.find((el) => el._id === target);
      return slug === 'Add' ? condition : !condition;
    }
    return false;
  };

  return (
    <StyledBox className={classes.Dialog}>
      <Dialog
        className={classes.Dialog}
        open={isOpen}
        onClose={closeDialog}
        aria-labelledby="form-dialog-title"
      >
        <DialogTitle className={classes.Dialog} id="form-dialog-title">
          Add Campaign
        </DialogTitle>
        <DialogContent>
          <Card>
            <UserListToolbar
              numSelected={0}
              filterName={filterName}
              onFilterName={handleFilterByName}
              slug="Doctors"
            />

            <Scrollbar>
              <TableContainer sx={{ minWidth: 600, width: 'fit-content' }}>
                <Table>
                  <UserListHead
                    order={order}
                    orderBy={orderBy}
                    headLabel={TABLE_HEAD}
                    rowCount={data ? data.length : 0}
                    numSelected={0}
                    onRequestSort={handleRequestSort}
                    onSelectAllClick={handleSelectAllClick}
                  />

                  <TableBody>
                    {data
                      ? filteredGroups
                          .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                          .map((row) => {
                            const { _id, name } = row;

                            return (
                              <TableRow
                                hover
                                key={_id}
                                tabIndex={-1}
                                role="checkbox"
                                selected={false}
                                aria-checked={false}
                              >
                                <TableCell padding="checkbox">
                                  <Checkbox
                                    checked={Boolean(selected.find((el) => el._id === _id))}
                                    onChange={() => {
                                      console.log('_id', _id);
                                      setSelected((st) =>
                                        st.find((el) => el._id === _id)
                                          ? st.filter((i) => i._id !== _id)
                                          : [...st, { _id, questions: 1 }]
                                      );
                                    }}
                                    // disabled={isAlreadyHere(targetId, row.employees)}
                                  />
                                </TableCell>
                                <TableCell component="th" padding="none">
                                  <Stack direction="row" alignItems="center" spacing={2}>
                                    <Avatar
                                      alt={name}
                                      src={`https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=${name
                                        .split(' ')
                                        .join('%20')}`}
                                    />
                                    <Typography variant="subtitle2" noWrap>
                                      {name}
                                    </Typography>
                                  </Stack>
                                </TableCell>
                                <TableCell align="left">
                                  <FormControl fullWidth>
                                    <Select
                                      labelId="demo-simple-select-label"
                                      id="demo-simple-select"
                                      value={selected.find((el) => el._id === _id)?.questions || 1}
                                      onChange={(e) => {
                                        setSelected((st) =>
                                          st.map((el) =>
                                            el._id === _id
                                              ? {
                                                  _id,
                                                  questions: e.target.value
                                                }
                                              : el
                                          )
                                        );
                                      }}
                                      disabled={
                                        Boolean(selected.find((el) => el._id === _id)) === false
                                      }
                                    >
                                      <MenuItem value={1}>1</MenuItem>
                                      <MenuItem value={2}>2</MenuItem>
                                      <MenuItem value={3}>3</MenuItem>
                                      <MenuItem value={4}>4</MenuItem>
                                      <MenuItem value={5}>5</MenuItem>
                                      <MenuItem value={6}>6</MenuItem>
                                      <MenuItem value={7}>7</MenuItem>
                                      <MenuItem value={8}>8</MenuItem>
                                      <MenuItem value={9}>9</MenuItem>
                                      <MenuItem value={10}>10</MenuItem>
                                    </Select>
                                  </FormControl>
                                </TableCell>
                              </TableRow>
                            );
                          })
                      : Array(5)
                          .fill()
                          .map(() => (
                            <TableRow>
                              <TableCell></TableCell>
                              <TableCell>
                                <Skeleton />
                              </TableCell>
                              <TableCell>
                                <Skeleton />
                              </TableCell>
                              <TableCell>
                                <Skeleton />
                              </TableCell>
                              <TableCell>
                                <Skeleton />
                              </TableCell>
                              <TableCell>
                                <Skeleton />
                              </TableCell>
                            </TableRow>
                          ))}
                    {emptyRows > 0 && (
                      <TableRow style={{ height: 53 * emptyRows }}>
                        <TableCell colSpan={6} />
                      </TableRow>
                    )}
                  </TableBody>
                  {data && isUserNotFound && (
                    <TableBody>
                      <TableRow>
                        <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                          <SearchNotFound searchQuery={filterName} />
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  )}
                </Table>
              </TableContainer>
            </Scrollbar>

            <TablePagination
              rowsPerPageOptions={[5, 10, 25]}
              component="div"
              count={data ? data.length : 0}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />
          </Card>
        </DialogContent>
        <DialogActions>
          <Button
            disabled={selected.length < 1}
            onClick={handleSubmit}
            variant="contained"
            color="primary"
          >
            Add
          </Button>
          <Button onClick={closeDialog} variant="contained" color="error">
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </StyledBox>
  );
};

export default AddToTableModal;

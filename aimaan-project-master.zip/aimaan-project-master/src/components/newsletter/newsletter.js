import React from 'react';
import './newsletter.css';
import '../../App.css';

const Newsletter = () => {
  return (
    <div>
      {/* <!-- newsletter --> */}
      <div className='newsletter' id='newsletter'>
        <h1>Stay ahead with the monthly newsletter</h1>
        <div className='subs'>
          <form action='#'>
            <input
              type='email'
              name='mail'
              id='mail'
              placeholder='example@domain.com'
              required
            />
            <button className='btn' type='submit' value='submit'>
              Subscribe
            </button>
          </form>
        </div>
      </div>
      {/* <!-- newsletter --> */}
    </div>
  );
};

export default Newsletter;

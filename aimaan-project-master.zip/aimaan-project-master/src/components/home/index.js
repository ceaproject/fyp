import React from 'react';
import Header from '../header/header';
import Welcome from '../welcome/welcome';
import About from '../about/about';
import Research from '../research/research';
import Services from '../services/services';
import Team from '../team/team';
import Clients from '../clients/clients';
import Newsletter from '../newsletter/newsletter';
import Footer from '../footer/footer';

const Home = () => {
  return (
    <div>
      <Header />
      <Welcome />
      <About />
      <Research />
      <Services />
      <Team />
      <Clients />
      <Newsletter />
      {/* <Footer /> */}
    </div>
  );
};

export default Home;

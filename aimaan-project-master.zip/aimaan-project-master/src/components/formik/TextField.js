import { TextField } from '@mui/material';
import React from 'react';
import { FormikHelpers } from '.';
import { handleFileChange } from './helpers';

const FormikTextField = ({
  formik,
  name,
  placeholder = '',
  type = 'text',
  fullWidth,
  label,
  className,
  multiline = false,
  minRows = 0,
  style = {},
}) => {
  const handleChange = (e) => {
    if (type === 'file') handleFileChange(e, formik);
    else FormikHelpers.handleTxtChange(e, formik);
  };
  return (
    <TextField
      className={className}
      variant='outlined'
      value={formik.values[name]}
      name={name}
      label={label || `${name.slice(0, 1).toUpperCase()}${name.slice(1)}`}
      onChange={handleChange}
      type={type}
      multiline={multiline}
      placeholder={
        placeholder || `${name.slice(0, 1).toUpperCase()}${name.slice(1)}`
      }
      minRows={minRows}
      fullWidth={Boolean(fullWidth)}
      style={style}
      error={formik.touched[name] && Boolean(formik.errors[name])}
      helperText={formik.touched[name] && formik.errors[name]}
      onBlur={formik.handleBlur}
    />
  );
};

export default FormikTextField;

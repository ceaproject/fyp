import React from 'react';

import { TextField, Checkbox } from '@mui/material';
import { Autocomplete } from '@mui/material';
import { handleAutoCompleteChange } from 'components/formik/helpers';

function FormikAutoComplete({
  label,
  name,
  formik,
  fullWidth = false,
  isDisabled = false,
  options = [],
}) {
  return (
    <Autocomplete
      disablePortal
      id={name}
      options={options}
      value={formik.values[name] || ''}
      disabled={isDisabled}
      onChange={(e, val) => handleAutoCompleteChange(e, val, name, formik)}
      getOptionLabel={(el) => el.name || el.label || el}
      error={formik.touched[name] && Boolean(formik.errors[name])}
      helperText={formik.touched[name] && formik.errors[name]}
      onBlur={formik.handleBlur}
      fullWidth={fullWidth}
      renderInput={(params) => (
        <TextField
          name={name}
          {...params}
          label={label || `${name.slice(0, 1).toUpperCase()}${name.slice(1)}`}
        />
      )}
    />
  );
}

export default FormikAutoComplete;

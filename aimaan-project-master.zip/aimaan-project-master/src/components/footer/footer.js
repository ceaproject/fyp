import React from 'react';
import './footer.css';
import '../../App.css';

const Footer = () => {
  return (
    <div>
      {/* <!-- footer --> */}
      <div className='footer' id='footer'>
        <div className='footer-widgets'>
          <div className='widget'>
            <h1>Pages</h1>
            <a href='#'>Home</a>
            <a href='#'>Events</a>
            <a href='#'>Institute</a>
            <a href='#'>About us</a>
            <a href='#'>Contact Us</a>
            <a href='#'>login</a>
          </div>
          <div className='widget'>
            <h1>Services</h1>
            <a href='#'>Social Media</a>
            <a href='#'>Marketing</a>
            <a href='#'>Talent</a>
            <a href='#'>Strategy</a>
            <a href='#'>Find Work</a>
            <a href='#'>Content Marketing​</a>
          </div>
          <div className='widget'>
            <h1>Agency</h1>
            <a href='#'>terms & conditions</a>
            <a href='#'>Licenses</a>
            <a href='#'>Become a member</a>
            <a href='#'>Help Center</a>
          </div>
          <div className='widget4 widget'>
            <h1>Contact</h1>
            <p>709 Honey Creek Dr. New York, NY 100284096 N Highland</p>
            <p>
              (236) 4563 963 3121 <br />
              (789) 4663 36536 212
            </p>
            <p>
              example1@domain.com <br />
              example2@domain.com
            </p>
          </div>
        </div>
        <div className='copyright'>
          <div className='left'>
            <p>All rights reserved 2022</p>
          </div>
          <div className='right'>
            <i className='fab fa-facebook'></i>
            <i className='fab fa-instagram'></i>
            <i className='fab fa-twitter'></i>
          </div>
        </div>
      </div>
      {/* <!-- footer --> */}
    </div>
  );
};

export default Footer;

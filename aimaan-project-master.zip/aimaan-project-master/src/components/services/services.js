import React from 'react';
import './services.css';
import '../../App.css';

const Services = () => {
  return (
    <div>
      {/* <!-- services section starts from here --> */}
      <div className='services' id='services'>
        <div className='section-heading'>
          <h1>Our Services</h1>
        </div>
        <div className='content'>
          <div className='service'>
            <img src='images/1.png' alt='img' />
            <h3>Social Media</h3>
            <p>
              Lorem ipsum dolor sit orot amet, cons ctetur atrd piing elit.​
            </p>
            <a href='#'>Learn More</a>
          </div>
          <div className='service'>
            <img src='images/2.png' alt='img' />
            <h3>Boost Your Confidence</h3>
            <p>
              Lorem ipsum dolor sit orot amet, cons ctetur atrd piing elit.​
            </p>
            <a href='#'>Learn More</a>
          </div>
          <div className='service'>
            <img src='images/3.png' alt='img' />
            <h3>Help You Recognize Your Talent</h3>
            <p>
              Lorem ipsum dolor sit orot amet, cons ctetur atrd piing elit.​
            </p>
            <a href='#'>Learn More</a>
          </div>
          <div className='service'>
            <img src='images/4.png' alt='img' />
            <h3>Strategy​​</h3>
            <p>
              Lorem ipsum dolor sit orot amet, cons ctetur atrd piing elit.​
            </p>
            <a href='#'>Learn More</a>
          </div>
          <div className='service'>
            <img src='images/5.png' alt='img' />
            <h3>Help You Find Work</h3>
            <p>
              Lorem ipsum dolor sit orot amet, cons ctetur atrd piing elit.​
            </p>
            <a href='#'>Learn More</a>
          </div>
          <div className='service'>
            <img src='images/6.png' alt='img' />
            <h3>Content Marketing​</h3>
            <p>
              Lorem ipsum dolor sit orot amet, cons ctetur atrd piing elit.​
            </p>
            <a href='#'>Learn More</a>
          </div>
        </div>
      </div>
      {/* <!-- services section ends here --> */}
    </div>
  );
};

export default Services;

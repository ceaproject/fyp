import React from 'react';
import './header.css';
import '../../App.css';

const Header = () => {
  return (
    <div id='home'>
      {/* <!-- header section starts from here --> */}
      <div className='header' id='header'>
        <div className='left'>
          <h3>StarTech Institute</h3>
          <h1>
            Empowering Talent, Teams, And Organizations To Unlock Their
            Potential
          </h1>
          <p>
            The StarTech Institute is here to help you, your team and your
            organization thrive in the new economy by providing innovative
            thought leadership.
          </p>
          <a href='#' className='btn'>
            Get Started
          </a>
        </div>
        <div className='right'>
          <img src='images/home-header-hero.png' alt='' />
        </div>
      </div>
      {/* <!-- header section ends here --> */}
    </div>
  );
};

export default Header;

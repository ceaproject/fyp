import React from 'react';
import './clients.css';
import '../../App.css';

const Clients = () => {
  return (
    <div>
      {/* <!-- our clients section starts from here --> */}
      <div className='clients' id='clients'>
        <div className='heading'>
          <h1>What Our Client Say's</h1>
          <p>OUR SUPPORT & ENCOURAGE</p>
        </div>
        <div className='content'>
          <div className='client'>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit
              ducimus accusamus exercitationem reprehenderit officia similique
              ex suscipit ad voluptatum! Quo a beatae facere.
            </p>
            <div className='client-name'>
              <img src='images/talent1.jpg' alt='img' />
              <p>Smith</p>
            </div>
          </div>
          <div className='client'>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit
              ducimus accusamus exercitationem reprehenderit officia similique
              ex suscipit ad voluptatum! Quo a beatae facere.
            </p>
            <div className='client-name'>
              <img src='images/talent3.jpg' alt='img' />
              <p>Oley</p>
            </div>
          </div>
          <div className='client'>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit
              ducimus accusamus exercitationem reprehenderit officia similique
              ex suscipit ad voluptatum! Quo a beatae facere.
            </p>
            <div className='client-name'>
              <img src='images/talent2.jpg' alt='img' />
              <p>Andris</p>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- our clients section ends here --> */}
    </div>
  );
};

export default Clients;

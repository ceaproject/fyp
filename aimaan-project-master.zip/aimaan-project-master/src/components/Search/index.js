import React from 'react';
import Search from '@mui/icons-material/Search';
import { Box, FormControl, InputAdornment, OutlinedInput } from '@mui/material';

const SearchInput = () => {
  return (
    <Box textAlign='center'>
      <FormControl variant='outlined'>
        <OutlinedInput
          sx={{
            '& .MuiOutlinedInput-notchedOutline': {
              borderColor: 'rgba(145, 158, 171, 0.32) !important',
            },
          }}
          size='small'
          startAdornment={
            <InputAdornment position='start'>
              <Search />
            </InputAdornment>
          }
          placeholder='Search'
        />
      </FormControl>
    </Box>
  );
};

export default SearchInput;

import React from 'react';
import './about.css';
import '../../App.css';

const About = () => {
  return (
    <div>
      {/* <!-- about us section starts from here --> */}
      <div className='about' id='about'>
        <div className='section-heading'>
          <h1>About Us</h1>
        </div>
        <div className='about-content'>
          <div className='left'>
            <img src='images/about.png' alt='img' />
          </div>
          <div className='right'>
            <p>
              The StarTech Institute is here to help you, your team and your
              organization thrive in the new economy by providing innovative
              thought leadership, research, data and expertise to support you on
              your journey to greatness.
            </p>
            <p>
              Established in 2022, the StarTech Institute is an innovation
              center focused on illuminating key trends and drivers of human and
              organizational performance. We develop and infuse robust
              scientific research, cutting-edge intellectual property, and
              state-of-the-art analytics into StarTech Solutions.
            </p>
            <p>
              We empower you, your team and your organization to exceed your
              potential.
            </p>
          </div>
        </div>
      </div>
      {/* <!-- about us section ends here --> */}
    </div>
  );
};

export default About;

import React from 'react';
import { Box, List, ListItem, ListItemText, Typography } from '@mui/material';

const Answer4 = (props) => {
  return (
    <Box
      sx={{
        '& li': {
          flexDirection: 'column',
        },
      }}
    >
      <Typography variant='body1'>
        The best talent recruitment strategy is the one that brings the right
        candidates to your organization. There is no one-size-fits-all
        recruitment strategy that will work for every company
      </Typography>
      <Typography variant='body1'>
        That said, organizations can take steps to optimize their hiring
        processes, and one of the most important things they can do is focus on
        delivering a positive candidate experience. The key is to show
        candidates that you care about them.
      </Typography>
      <Typography variant='body1'>
        Throughout the hiring process, you should strive to leave a positive
        impression, starting with clear and accurate job ads and continuing by
        communicating regularly with candidates throughout the process — even
        unsuccessful ones.
      </Typography>
      <Typography variant='body1'>
        We recommend that organizations follow what we call the “CARE” model
      </Typography>

      <List>
        <ListItem divider sx={{ display: 'list-item' }}>
          <ListItemText
            primary='Configure: Configure your talent acquisition strategy with the right people, processes, and
technology. Make sure you have the right team members doing the right work. Also check to
see whether there are any tools that might make it easier to perform their recruitment
tasks, such as AI sourcing tools or requisition workflow automation. Finally, make sure
you’ve built accountability into your team as well because accountability drives
commitment.
'
          />
          <ListItemText
            primary='Adapt: No two candidates are alike, so your hiring process should be customized for each
role as well as each candidate. Consider the candidate’s journey and make sure you’re
creating an experience that targets what you want them to think, know and feel at each
stage. It may be helpful to create a hiring persona with the traits, motivations and
preferences typically found in a candidate segment
'
          />
          <ListItemText
            primary='Refine: Use technology to refine the hiring process and personalize your approach to the
candidate. For example, chatbots can increase the level of candidate care by offering 24/7
responsiveness to questions, scheduling appointments and interviews and providing
updates. Digital assessments can notify candidates how they performed and offer
constructive feedback.
'
          />
          <ListItemText
            primary='Elevate: Start treating candidates as if you’ve already hired them. By treating candidates as
“employees-elect,” your candidates will feel as if they’re already part of your company. This
is an opportunity to share your culture and values, so your hiring process becomes an
extension of your onboarding process. This way, candidates are ready to start their job and
make an impact on their first day. And even unsuccessful candidates will leave with a
positive impression of your brand and culture.'
          />
        </ListItem>
      </List>
    </Box>
  );
};

export default Answer4;

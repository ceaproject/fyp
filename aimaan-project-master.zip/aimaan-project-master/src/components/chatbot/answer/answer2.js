import React from 'react';
import { Box, List, ListItem, ListItemText, Typography } from '@mui/material';

const Answer2 = (props) => {
  return (
    <Box
      sx={{
        '& li': {
          flexDirection: 'column',
        },
      }}
    >
      <Typography variant='subtitle1'>
        Talent sourcing, also called candidate sourcing, is the process of
        conducting a proactive search for qualified candidates who are a good
        fit for current or planned job openings. A sourcing strategy includes
        defining the employer brand, setting job and candidate requirements, and
        identifying where to look for qualified individuals. The goal of talent
        sourcing is to build a pipeline of candidates that can fill current and
        future job vacancies.
      </Typography>
      <Typography variant='body1'>
        To find candidates, organizations can turn to a variety of resources:
      </Typography>
      <List>
        <ListItem divider sx={{ display: 'list-item' }}>
          <ListItemText primary='High-potential internal candidates in development programs' />
          <ListItemText
            primary='Passive candidates in similar roles from other organizations identified
through social media or other recruitment technology platforms'
          />
          <ListItemText primary='Employee referrals' />
          <ListItemText primary='Community and affinity groups' />
          <ListItemText primary='Corporate alumni groups' />
        </ListItem>
      </List>
    </Box>
  );
};

export default Answer2;

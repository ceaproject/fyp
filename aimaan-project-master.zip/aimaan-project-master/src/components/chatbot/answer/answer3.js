import React from 'react';
import { Box, List, ListItem, ListItemText, Typography } from '@mui/material';

const Answer3 = (props) => {
  return (
    <Box
      sx={{
        '& li': {
          flexDirection: 'column',
        },
      }}
    >
      <Typography variant='body1'>
        A full lifecycle outsourced talent recruitment solution — one that
        starts with job profiling and continues through to the onboarding of the
        new hire — has a number of benefits. Depending on the recruitment
        process outsourcing (RPO) solution you choose, among these benefits are
        the following:
      </Typography>
      <List>
        <ListItem divider sx={{ display: 'list-item' }}>
          <ListItemText primary='Saving time through automated processes' />
          <ListItemText primary='Building a pipeline of candidates who match your needs  ' />
          <ListItemText
            primary='Shortening
      the time to fill positions'
          />
          <ListItemText primary='Reducing the risk of bad hires' />

          <ListItemText
            primary='Allowing your resources to focus on other high-priority work
      '
          />
          <ListItemText
            primary='Addressing diversity and inclusion requirements by eliminating
      conscious and unconscious bias'
          />
          <ListItemText
            primary='Making costs more predictable because you only pay for the
      resources you need'
          />
          <ListItemText
            primary='Improving consistency across hiring processes  Providing a
      coherent, engaging candidate experience'
          />
          <ListItemText
            primary='Aligning recruitment strategies with overall business
      strategies'
          />
          <ListItemText primary='Simplifying management of the talent acquisition function' />
          <ListItemText primary='Giving a holistic view of the talent recruitment process' />
          <ListItemText
            primary='Increasing flexibility so the hiring organization can
      scale resources quickly in response to changes in demand'
          />
        </ListItem>
      </List>
    </Box>
  );
};

export default Answer3;

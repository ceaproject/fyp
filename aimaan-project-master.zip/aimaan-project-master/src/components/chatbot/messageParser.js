class MessageParser {
  constructor(actionProvider, state) {
    this.actionProvider = actionProvider;
    this.state = state;
  }

  parse(message) {
    const lowerCase = message.toLowerCase();
    this.actionProvider.greet(lowerCase);

    if (lowerCase.includes('javascript') || lowerCase.includes('js')) {
      // this.actionProvider.handleJavascriptQuiz();
    }
  }
}

export default MessageParser;

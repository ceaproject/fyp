// ActionProvider starter code
class ActionProvider {
  constructor(
    createChatBotMessage,
    setStateFunc,
    createClientMessage,
    stateRef,
    createCustomMessage,
    ...rest
  ) {
    this.createChatBotMessage = createChatBotMessage;
    this.setState = setStateFunc;
    this.createClientMessage = createClientMessage;
    this.stateRef = stateRef;
    this.createCustomMessage = createCustomMessage;
  }

  greet = (text) => {
    let message;
    if (text.includes('hi') || text.includes('hello'))
      message = this.createChatBotMessage('Hello Friend!');
    this.addMessageToState(message);
  };

  option1handler = () => {
    const message = this.createChatBotMessage(
      `Here is your answer
    `,
      {
        widget: 'answer1',
      }
    );

    this.addMessageToState(message);
  };
  option2handler = () => {
    const message = this.createChatBotMessage(
      `Here is your answer
    `,
      {
        widget: 'answer2',
      }
    );

    this.addMessageToState(message);
  };
  option3handler = () => {
    const message = this.createChatBotMessage(
      `Here is your answer
    `,
      {
        widget: 'answer3',
      }
    );

    this.addMessageToState(message);
  };
  option4handler = () => {
    const message = this.createChatBotMessage(
      `Here is your answer
    `,
      {
        widget: 'answer4',
      }
    );

    this.addMessageToState(message);
  };

  handleJavascriptQuiz = () => {
    const message = this.createChatBotMessage(
      'Fantastic. Here is your quiz. Good luck!'
    );

    this.addMessageToState(message);
  };

  addMessageToState = (message) => {
    this.setState((st) => ({
      ...st,
      messages: [...st.messages, message],
    }));
  };
}

export default ActionProvider;

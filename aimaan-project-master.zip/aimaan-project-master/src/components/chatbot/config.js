// Config starter code
import { createChatBotMessage } from 'react-chatbot-kit';
import Answer1 from './answer/answer1';
import Answer2 from './answer/answer2';
import Answer3 from './answer/answer3';
import Answer4 from './answer/answer4';
import Options from './option';

const config = {
  botName: 'StarTec Bot',
  initialMessages: [
    createChatBotMessage(`Welcome to Startech! How Can I help you ?`, {
      widget: 'options',
    }),
  ],
  widgets: [
    {
      widgetName: 'options',
      widgetFunc: (props) => <Options {...props} />,
    },
    {
      widgetName: 'answer1',
      widgetFunc: (props) => <Answer1 {...props} />,
    },
    {
      widgetName: 'answer2',
      widgetFunc: (props) => <Answer2 {...props} />,
    },
    {
      widgetName: 'answer3',
      widgetFunc: (props) => <Answer3 {...props} />,
    },
    {
      widgetName: 'answer4',
      widgetFunc: (props) => <Answer4 {...props} />,
    },
  ],
};

export default config;

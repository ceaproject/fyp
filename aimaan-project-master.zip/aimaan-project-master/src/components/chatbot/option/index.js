import React from 'react';

import './options.css';

const Options = (props) => {
  const options = [
    {
      text: 'What are the main stages of talent recruitment?',
      handler: props.actionProvider.option1handler,
      id: 1,
    },
    {
      text: 'What is Talent Sourcing',
      handler: () => {},
      id: 2,
      handler: props.actionProvider.option2handler,
    },
    {
      text: '. What are the benefits of outsourcing talent acquisition?',
      handler: props.actionProvider.option3handler,

      id: 3,
    },
    {
      text: '. What is the best talent recruitment strategy?',
      handler: props.actionProvider.option4handler,
      id: 4,
    },
  ];

  const buttonsMarkup = options.map((option) => (
    <button key={option.id} onClick={option.handler} className='option-button'>
      {option.text}
    </button>
  ));

  return <div className='options-container'>{buttonsMarkup}</div>;
};

export default Options;

import { SmartToy } from '@mui/icons-material';
import { Button, IconButton, Popover } from '@mui/material';
import { useToggleInput } from 'hooks';
import React from 'react';
import Chatbot from 'react-chatbot-kit';
import ActionProvider from './actionProvider';
import config from './config';
import MessageParser from './messageParser';

export default () => {
  const [open, toggleOpen] = useToggleInput(false);

  return (
    <div>
      <IconButton
        sx={{
          position: 'fixed',
          bottom: '10px',
          right: '10px',
        }}
        color='primary'
        size='large'
        variant='contained'
        onClick={toggleOpen}
      >
        <SmartToy fontSize='large' />
      </IconButton>
      <div
        className={`${open && 'ChatBot'}`}
        style={{
          display: open ? 'block' : 'none',
        }}
      >
        <div style={{ maxWidth: '300px' }}>
          <Chatbot
            config={config}
            messageParser={MessageParser}
            actionProvider={ActionProvider}
          />
        </div>
      </div>
    </div>
  );
};

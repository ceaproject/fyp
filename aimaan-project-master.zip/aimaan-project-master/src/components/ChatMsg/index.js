import React from 'react';
import { styled } from '@mui/material/styles';
import PropTypes from 'prop-types';
import cx from 'clsx';
import Grid from '@mui/material/Grid';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import { Box, FormControl, InputAdornment, OutlinedInput } from '@mui/material';
import { Send } from '@mui/icons-material';
import { useTextInput } from 'hooks';

const PREFIX = 'ChatMsg';

const classes = {
  root: `${PREFIX}-root`,
  avatar: `${PREFIX}-avatar`,
  leftRow: `${PREFIX}-leftRow`,
  rightRow: `${PREFIX}-rightRow`,
  msg: `${PREFIX}-msg`,
  left: `${PREFIX}-left`,
  right: `${PREFIX}-right`,
  leftFirst: `${PREFIX}-leftFirst`,
  leftLast: `${PREFIX}-leftLast`,
  rightFirst: `${PREFIX}-rightFirst`,
  rightLast: `${PREFIX}-rightLast`,
};

const StyledGrid = styled(Grid)(({ theme: { palette, spacing } }) => {
  const radius = spacing(1.5);
  const size = spacing(4);
  const rightBgColor = palette.primary.light;
  // if you want the same as facebook messenger, use this color '#09f'
  return {
    [`&.${classes.root}`]: {
      marginBottom: '1.5rem',
    },
    [`& .${classes.avatar}`]: {
      width: size,
      height: size,
    },
    [`& .${classes.leftRow}`]: {
      textAlign: 'left',
    },
    [`& .${classes.rightRow}`]: {
      textAlign: 'right',
    },
    [`& .${classes.msg}`]: {
      padding: spacing(1, 2),
      borderRadius: 4,
      marginBottom: 4,
      display: 'inline-block',
      wordBreak: 'break-word',
      fontFamily:
        // eslint-disable-next-line max-len
        '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"',
      fontSize: '14px',
    },
    [`& .${classes.left}`]: {
      borderTopRightRadius: radius,
      borderBottomRightRadius: radius,
      backgroundColor: 'rgba(145, 158, 171, 0.16)',
    },
    [`& .${classes.right}`]: {
      borderTopLeftRadius: radius,
      borderBottomLeftRadius: radius,
      backgroundColor: rightBgColor,
      color: palette.common.white,
    },
    [`& .${classes.leftFirst}`]: {
      borderTopLeftRadius: 0,
    },
    [`& .${classes.leftLast}`]: {
      borderBottomLeftRadius: 0,
    },
    [`& .${classes.rightFirst}`]: {
      borderTopRightRadius: 0,
    },
    [`& .${classes.rightLast}`]: {
      borderBottomRightRadius: 0,
    },
  };
});

const ChatMsg = (props) => {
  const {
    avatar,
    messages,
    side,
    GridContainerProps,
    GridItemProps,
    AvatarProps,
    getTypographyProps,
  } = props;

  const attachClass = (index) => {
    if (index === 0) {
      return classes[`${side}First`];
    }
    if (index === messages.length - 1) {
      return classes[`${side}Last`];
    }
    return '';
  };

  return (
    <StyledGrid
      container
      spacing={1}
      justify={side === 'right' ? 'flex-end' : 'flex-start'}
      {...GridContainerProps}
      className={classes.root}
    >
      {side === 'left' && messages.length > 0 && (
        <Grid item {...GridItemProps}>
          <Avatar
            src={''}
            {...AvatarProps}
            className={cx(classes.avatar, AvatarProps.className)}
          />
        </Grid>
      )}
      <Grid item xs={8} sm={12}>
        <Box>
          {messages.map((msg, i) => {
            const TypographyProps = getTypographyProps(msg, i, props);
            return (
              // eslint-disable-next-line react/no-array-index-key
              <div key={msg.id || i} className={classes[`${side}Row`]}>
                <Typography
                  align={'left'}
                  {...TypographyProps}
                  className={cx(
                    classes.msg,
                    classes[side],
                    attachClass(i),
                    TypographyProps.className
                  )}
                >
                  {msg.text}
                </Typography>
              </div>
            );
          })}
        </Box>
      </Grid>
    </StyledGrid>
  );
};

ChatMsg.propTypes = {
  avatar: PropTypes.string,
  messages: PropTypes.arrayOf(PropTypes.string),
  side: PropTypes.oneOf(['left', 'right']),
  GridContainerProps: PropTypes.shape({}),
  GridItemProps: PropTypes.shape({}),
  AvatarProps: PropTypes.shape({}),
  getTypographyProps: PropTypes.func,
};
ChatMsg.defaultProps = {
  avatar: '',
  messages: [],
  side: 'left',
  GridContainerProps: {},
  GridItemProps: {},
  AvatarProps: {},
  getTypographyProps: () => ({}),
};

export default ChatMsg;

import React, { useState } from 'react';
import {
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormLabel,
} from '@mui/material';

const jobFilter = [
  'ICT',
  'Engineering',
  'Business',
  'Service',
  'Homecare',
  'Medical',
  'Education',
  'Others',
];

const educationGroup = ['hs', 'certificate', 'diploma', 'masters', 'other'];

const ageGroup = [
  { id: '1', label: 'Teenager', min: 0, max: 19 },
  { id: '2', label: '20-35', min: 19, max: 35 },
  { id: '3', label: '35-45', min: 35, max: 45 },
  { id: '4', label: '45-60', min: 45, max: 60 },
  { id: '5', label: '>60', min: 60, max: 100 },
];
const initialjob = {
  ICT: false,
  Engineering: false,
  Business: false,
  Service: false,
  Homecare: false,
  Medical: false,
  Education: false,
  Others: false,
};
const initialeducation = {
  hs: false,
  certificate: false,
  diploma: false,
  masters: false,
  other: false,
};
const initialage = {
  1: false,
  2: false,
  3: false,
  4: false,
  5: false,
};
const initialgender = {
  male: false,
  female: false,
};

export default function UserFilter({
  users,
  open,
  toggleDialog,
  setFilteredUsers,
}) {
  const [job, setJob] = useState(initialjob);
  const [education, setEducation] = useState(initialeducation);
  const [age, setAge] = useState(initialage);

  const [gender, setGender] = useState(initialgender);

  const handleClear = () => {
    setJob(initialjob);
    setEducation(initialeducation);
    setAge(initialage);
    setGender(initialgender);
    setFilteredUsers(users);
  };

  const handleFilter = () => {
    setFilteredUsers(() => {
      let newState = [...users];
      let jobEntries = Object.entries(job)
        .filter((el) => Boolean(el[1]))
        .map((el) => el[0]);
      let ageEntries = Object.entries(age)
        .filter((el) => Boolean(el[1]))
        .map((el) => el[0]);
      let educationEntries = Object.entries(education)
        .filter((el) => Boolean(el[1]))
        .map((el) => el[0]);
      let genderEntries = Object.entries(gender)
        .filter((el) => Boolean(el[1]))
        .map((el) => el[0]);

      console.log('jobEntries', jobEntries);

      if (jobEntries.length)
        newState = newState.filter((el) => jobEntries.includes(el.studyField));
      if (educationEntries.length)
        newState = newState.filter((el) =>
          educationEntries.includes(el.education)
        );
      if (ageEntries.length)
        newState = newState.filter((el) => {
          let condition = false;
          ageEntries.forEach((st) => {
            console.log('st', st);
            console.log('ageGroup[st]', ageGroup[st - 1]);
            if (
              el.age >= ageGroup[st - 1].min &&
              el.age <= ageGroup[st - 1].max
            )
              condition = true;
          });

          return condition;
        });
      if (genderEntries.length)
        newState = newState.filter((el) => genderEntries.includes(el.gender));

      return newState;
    });
  };

  const handleEducationChange = (event) => {
    setEducation((st) => ({
      ...st,
      [event.target.name]: event.target.checked,
    }));
  };
  const handleJobChange = (event) => {
    setJob((st) => ({
      ...st,
      [event.target.name]: event.target.checked,
    }));
  };
  const handleGenderChange = (event) => {
    setGender((st) => ({
      ...st,
      [event.target.name]: event.target.checked,
    }));
  };
  const handleAgeChange = (event) => {
    setAge((st) => ({
      ...st,
      [event.target.name]: event.target.checked,
    }));
  };

  return (
    <Dialog open={open} onClose={toggleDialog}>
      <DialogTitle>Filter Users</DialogTitle>
      <DialogContent
        style={{
          display: 'flex',
          alignItems: 'flex-start',
          justifyContent: 'space-around',
        }}
      >
        <div>
          <FormControl sx={{ m: 3 }} component='fieldset' variant='standard'>
            <FormLabel component='legend'>By Job Family</FormLabel>
            <FormGroup>
              {jobFilter.map((el) => (
                <FormControlLabel
                  key={el}
                  control={
                    <Checkbox
                      checked={job[el]}
                      onChange={handleJobChange}
                      name={el}
                    />
                  }
                  label={el}
                />
              ))}
            </FormGroup>
          </FormControl>
        </div>
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'flex-start',
            gap: 0,
          }}
        >
          <FormControl
            sx={{ m: 3, mb: 0 }}
            component='fieldset'
            variant='standard'
          >
            <FormLabel component='legend'>Age Group</FormLabel>
            <FormGroup>
              {ageGroup.map((el) => (
                <FormControlLabel
                  key={el.id}
                  control={
                    <Checkbox
                      checked={age[el.id]}
                      onChange={handleAgeChange}
                      name={el.id}
                    />
                  }
                  label={el.label}
                />
              ))}
            </FormGroup>
          </FormControl>
          <FormControl sx={{ m: 3 }} component='fieldset' variant='standard'>
            <FormLabel component='legend'>Gender</FormLabel>
            <FormGroup>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={gender.male}
                    onChange={handleGenderChange}
                    name={'male'}
                  />
                }
                label={'Male'}
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={gender.female}
                    onChange={handleGenderChange}
                    name={'female'}
                  />
                }
                label={'Female'}
              />
            </FormGroup>
          </FormControl>
        </div>
        <div>
          <FormControl sx={{ m: 3 }} component='fieldset' variant='standard'>
            <FormLabel component='legend'>By Education</FormLabel>
            <FormGroup>
              {educationGroup.map((el) => (
                <FormControlLabel
                  key={el}
                  control={
                    <Checkbox
                      checked={education[el]}
                      onChange={handleEducationChange}
                      name={el}
                    />
                  }
                  label={el}
                />
              ))}
            </FormGroup>
          </FormControl>
        </div>
      </DialogContent>
      <DialogActions>
        <Button
          variant='contained'
          onClick={handleFilter}
          color='success'
          style={{ color: '#fff' }}
        >
          Filter
        </Button>
        <Button
          variant='contained'
          onClick={handleClear}
          color='warning'
          style={{ color: '#fff' }}
        >
          Clear All Filters
        </Button>
        <Button color='error' variant='contained' onClick={toggleDialog}>
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
}

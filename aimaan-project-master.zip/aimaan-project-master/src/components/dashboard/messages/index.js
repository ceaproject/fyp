// material
import {
  Avatar,
  Box,
  Button,
  Container,
  FormControl,
  Grid,
  IconButton,
  InputAdornment,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  OutlinedInput,
  Skeleton,
  Typography,
} from '@mui/material';
// components
import Page from 'components/Page';
import ChatMsg from 'components/ChatMsg';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import { createNewChat, getAllChats } from 'store/slices/chats/extraReducers';
import { useLocation } from 'react-router-dom';
import SearchInput from 'components/Search';
import { Send } from '@mui/icons-material';
import { useTextInput } from 'hooks';
import { TOKEN_KEY } from 'api';
import { newMessage, setActiveChat } from 'store/slices/chats';
import { logout } from 'store/slices/auth';

export default function Messages() {
  const { chats, fetching, activeChat } = useSelector((st) => st.chats);
  const { user } = useSelector((st) => st.auth);
  const [] = useState(null);
  const [chatMessages, setChatMessages] = useState([]);

  const dispatch = useDispatch();
  const location = useLocation();
  const [message, handleChange, resetMessage] = useTextInput('');

  const handleSend = (e) => {
    e.preventDefault();

    dispatch({ type: 'action', data: message });
    dispatch({
      type: 'chats/sendMessage',
      payload: {
        chat: activeChat._id,
        text: message,
        token: localStorage.getItem(TOKEN_KEY),
      },
    });
    resetMessage();
  };

  useEffect(() => {
    if (!fetching) dispatch(setActiveChat(chats[0]));
  }, [fetching]);

  useEffect(() => {
    if (fetching) return;
    let query = new URLSearchParams(location.search).get('user');
    if (!query) return;
    query = `${query}`;

    let newChat = chats?.find((el) =>
      Boolean(
        el.participants[0]._id === query || el.participants[1]._id === query
      )
    );

    if (newChat) dispatch(setActiveChat(newChat));
    else
      dispatch(createNewChat(query)).then(({ err, payload }) => {
        if (!err) console.log('payload', payload);
      });
  }, [location.search, fetching]);

  const getParticipant = (chat, isMe = false, field = 'name') => {
    let isMe1st = chat.participants[0]._id === user._id;
    console.log('chat.participants', chat.participants);
    //
    if (isMe) {
      return isMe1st
        ? chat.participants[0][field]
        : chat.participants[1][field];
    } else
      return isMe1st
        ? chat.participants[1][field]
        : chat.participants[0][field];
  };

  const getMessagesGroup = (messages, i) => {
    if (
      messages[i + 1] &&
      messages[i + 1].sender._id === messages[i].sender._id
    ) {
      return [messages[i], ...getMessagesGroup(messages, i + 1)];
    } else return [messages[i]];
  };

  const getNewMessages = () => {
    let newMessages = [];
    for (let i = 0; i < activeChat.messages.length; i++) {
      if (
        activeChat.messages[i].sender._id ===
        activeChat.messages[i + 1]?.sender._id
      ) {
        let groupMessages = getMessagesGroup(activeChat.messages, i);
        newMessages.push({
          side:
            activeChat.messages[i].sender._id === user._id ? 'right' : 'left',
          avatar: `https://ui-avatars.com/api/?rounded=true&name=Ali Raza`,
          messages: groupMessages,
        });
        i = i + groupMessages.length;
      } else {
        newMessages.push({
          side:
            activeChat.messages[i].sender._id === user._id ? 'right' : 'left',
          avatar: `https://ui-avatars.com/api/?rounded=true&name=Ali Raza`,
          messages: [activeChat.messages[i]],
        });
      }
    }
    console.log('newMessages', newMessages);
    setChatMessages(newMessages);
  };

  useEffect(() => {
    if (!activeChat) return;

    getNewMessages();
  }, [activeChat]);

  return (
    <Page title='Messages | Aimaan-Project'>
      <Container>
        {!fetching && chats && chats.length === 0 && (
          <Typography variant='h5'>You Do have have any chats yet!</Typography>
        )}
        <Grid container sx={{ minHeight: '80vh' }}>
          <Grid
            item
            xs={2}
            sm={4}
            sx={{
              py: 3,
              border: '1px solid #919eab3d',
              borderRight: 0,
              height: '80vh',
              overflowY: 'scroll',
            }}
          >
            {fetching ? (
              Array(10)
                .fill()
                .map((el) => (
                  <Skeleton
                    style={{ marginBottom: '1rem' }}
                    key={Math.floor(Math.random() * 1000)}
                  />
                ))
            ) : (
              <>
                <SearchInput />
                <List>
                  {chats?.map((chat) => (
                    <ListItem
                      divider
                      sx={{
                        ['&:hover']: {
                          backgroundColor: 'rgba(145, 158, 171, 0.08)',
                          cursor: 'pointer',
                        },
                        backgroundColor:
                          activeChat?._id === chat._id &&
                          'rgba(145, 158, 171, 0.16)',
                        mb: 2,
                      }}
                      onClick={() => dispatch(setActiveChat(chat))}
                    >
                      <ListItemAvatar>
                        <Avatar
                          src={`https://ui-avatars.com/api/?rounded=true&name=${getParticipant(
                            chat,
                            false,
                            'name'
                          )}`}
                        />
                      </ListItemAvatar>
                      <ListItemText
                        primary={getParticipant(chat, false, 'name')}
                        secondary={
                          getParticipant(chat, false, 'messages')?.[0]?.text ||
                          ''
                        }
                      />
                    </ListItem>
                  ))}
                </List>
              </>
            )}
          </Grid>
          <Grid
            item
            xs={10}
            sm={8}
            sx={{
              p: 3,
              border: '1px solid #919eab3d',
              display: 'flex',
              justifyContent: 'space-between',
              flexDirection: 'column',
              minHeight: '100%',
            }}
          >
            <Box
              sx={{
                height: '60vh',
                overflowY: 'scroll',
                paddingRight: 1,
              }}
            >
              {activeChat &&
                chatMessages.map((msg) => (
                  <ChatMsg
                    key={Math.floor(Math.random() * 10000)}
                    messages={msg.messages}
                    side={msg.side}
                  />
                ))}
            </Box>
            <form onSubmit={handleSend}>
              <FormControl variant='outlined' fullWidth>
                <OutlinedInput
                  value={message}
                  onChange={handleChange}
                  sx={{
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'rgba(145, 158, 171, 0.32) !important',
                    },
                  }}
                  fullWidth
                  size='small'
                  endAdornment={
                    <InputAdornment position='start'>
                      <Button
                        type='submit'
                        variant='contained'
                        endIcon={<Send />}
                        color='primary'
                        size='small'
                        sx={{ backgroundColor: 'primary.light' }}
                      >
                        Send
                      </Button>
                    </InputAdornment>
                  }
                  placeholder='Search'
                />
              </FormControl>
            </form>
          </Grid>
        </Grid>
      </Container>
    </Page>
  );
}

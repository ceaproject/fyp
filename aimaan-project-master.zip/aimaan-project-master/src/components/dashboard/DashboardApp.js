// material
import { Box, Grid, Container, Typography } from '@mui/material';
// components
import Page from 'components/Page';
import AppCard from './AppCard';
import userIcon from '@iconify/icons-ant-design/user';
import publishedIcon from '@iconify/icons-ant-design/android-filled';
import archievedIcon from '@iconify/icons-ant-design/customer-service-filled';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { getAllEvents } from 'store/slices/events/extraReducers';
import { getAllUsers, getMyBookings } from 'store/slices/users/extraReducers';

// ----------------------------------------------------------------------

export default function DashboardApp() {
  const dispatch = useDispatch();
  const { user } = useSelector((st) => st.auth);
  const { users } = useSelector((st) => st.users);
  const { events } = useSelector((st) => st.events);
  const { bookings } = useSelector((st) => st.auth);

  useEffect(() => {
    if (user.role === 'admin') if (!users) dispatch(getAllUsers());
  }, [users]);

  useEffect(() => {
    if (!events) dispatch(getAllEvents());
  }, [events]);
  useEffect(() => {
    if (!bookings) dispatch(getMyBookings());
  }, [bookings]);

  return (
    <Page title='Dashboard | Spa-Dashboard'>
      <Container maxWidth='xl'>
        <Box sx={{ pb: 5 }}>
          <Typography variant='h4'>Hi, Welcome back</Typography>
        </Box>
        <Grid
          container
          spacing={3}
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Grid item xs={12} sm={6} md={4}>
            <AppCard
              num={users?.length || 0}
              icon={userIcon}
              title='Users'
              color='info'
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <AppCard
              num={events?.length || 0}
              icon={publishedIcon}
              title='Events'
              color='warning'
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <AppCard
              num={bookings?.length || 0}
              icon={publishedIcon}
              title='Registered Events'
              color='success'
            />
          </Grid>
        </Grid>
      </Container>
    </Page>
  );
}

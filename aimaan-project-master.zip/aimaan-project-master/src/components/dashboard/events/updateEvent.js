// material
import { Container } from '@mui/material';
// components
import Page from 'components/Page';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import {
  createEvent,
  getAllEvents,
  updateEvent,
} from 'store/slices/events/extraReducers';
import EventForm from './EventForm';
//
// ----------------------------------------------------------------------

export default function UpdateEvent() {
  const { events } = useSelector((st) => st.events);
  const dispatch = useDispatch();
  const [event, setEvent] = useState();
  const { id } = useParams();

  useEffect(() => {
    if (!events) return dispatch(getAllEvents());

    console.log('events', events);
    console.log('id', id);
    let tmp = events.find((el) => el._id === id);
    console.log('tmp', tmp);
    setEvent(tmp);
  }, [id, events]);

  const handleSubmit = (values) => {
    console.log('values', values);
    dispatch(updateEvent({ id, updatedEvent: values }));
  };

  return (
    <Page title='UpdateEvent | Aimaan-Project'>
      <Container>
        <EventForm handleSubmit={handleSubmit} event={event} slug='Update' />
      </Container>
    </Page>
  );
}

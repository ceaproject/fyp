import React, { useEffect, useState } from 'react';
import * as Yup from 'yup';
import { useFormik } from 'formik';
import { FormikAutoComplete, FormikTextField } from 'components/formik';
import { useSelector } from 'react-redux';
import { Button, Container, TextField, Typography } from '@mui/material';
import { Add } from '@mui/icons-material';
import { toast } from 'react-toastify';

const EventForm = ({ handleSubmit, slug = 'Create', event }) => {
  const { loading } = useSelector((st) => st.events);
  const { users } = useSelector((st) => st.users);

  const validationSchema = Yup.object().shape({
    title: Yup.string().required('Title is required'),
    info: Yup.string().required('Title is required'),
    links: Yup.string().required('Title is required'),
    type: Yup.object().required('Type is Required'),
    coordinator: Yup.object(),
  });
  const [image, setImage] = useState('');
  const [video, setVideo] = useState('');

  useEffect(() => {
    if (!event) return;

    formik.setValues({
      ...event,
      links: event.links.join(','),
      type: {
        name: event.type,
        value: event.type,
      },
      coordinator: event.coordinator
        ? {
            name: event.coordinator.name,
            value: event.coordinator._id,
          }
        : '',
    });
  }, [event]);

  const formik = useFormik({
    initialValues: {
      title: '',
      info: '',
      links: '',
      type: {
        value: 'events',
        name: 'Events',
      },
    },
    validationSchema: validationSchema,
    onSubmit: () => {
      console.log(`'formik.va'`, formik.values);
      handleSubmit({ ...formik.values });
    },
  });
  const { errors, touched, values, isSubmitting, getFieldProps } = formik;

  useEffect(() => {
    formik.setSubmitting(loading);
  }, [loading]);

  useEffect(() => {
    console.log('formik.values', formik.values);
    console.log('formik.errors', formik.errors);
  }, [formik.values]);

  const handleAutoCompleteChange = (e, value, key) => {
    formik.setFieldValue(key, value);
    formik.handleBlur(e);
  };

  const handleForm = async () => {
    console.log('formik.values', formik.values);

    if (!image) return toast.error('Image is required!');

    handleSubmit({
      ...formik.values,
      image,
      video,
      type: formik.values.type.value,
      coordinator: formik.values.coordinator._id,
    });
  };

  return (
    <Container
      sx={{
        maxWidth: '400px !important',
        '& .MuiFormControl-root': {
          marginBottom: 3,
        },
      }}
    >
      <Typography variant='h5' align='center' sx={{ mb: 2 }}>
        Create Event
      </Typography>
      <FormikTextField formik={formik} name='title' label='Title' fullWidth />
      <FormikTextField formik={formik} name='info' label='Info' fullWidth />

      <TextField
        type='file'
        variant='outlined'
        label='image'
        name='image'
        fullWidth
        onChange={(e) => {
          if (!e.target.files[0].name.startsWith('image'))
            setImage(e.target.files[0]);
        }}
      />
      <TextField
        type='file'
        variant='outlined'
        label='video'
        name='video'
        fullWidth
        onChange={(e) => {
          setVideo(e.target.files[0]);
        }}
      />

      <FormikTextField
        formik={formik}
        name='links'
        label='Links (separate by comma ",")'
        fullWidth
      />
      <FormikAutoComplete
        options={users ? users.filter((el) => el.role === 'coordinator') : []}
        handleChange={handleAutoCompleteChange}
        formik={formik}
        name='coordinator'
        placeholder='Coordinator'
        fullWidth
      />
      <FormikAutoComplete
        options={[
          {
            value: 'training',
            name: 'Training',
          },
          {
            value: 'workshop',
            name: 'Workshop',
          },
          {
            value: 'events',
            name: 'Events',
          },
        ]}
        handleChange={handleAutoCompleteChange}
        formik={formik}
        name='type'
        placeholder='Event Type'
        fullWidth
      />
      <Button
        disabled={!formik.dirty || !formik.isValid || formik.isSubmitting}
        size='medium'
        variant='contained'
        onClick={handleForm}
        endIcon={<Add />}
      >
        {slug}
      </Button>
    </Container>
  );
};

export default EventForm;

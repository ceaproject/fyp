// material
import { Container } from '@mui/material';
// components
import Page from 'components/Page';
import { useDispatch } from 'react-redux';
import { createEvent } from 'store/slices/events/extraReducers';
import EventForm from './EventForm';
//
// ----------------------------------------------------------------------

export default function Event() {
  const dispatch = useDispatch();

  const handleSubmit = (values) => {
    console.log('values', values);
    dispatch(createEvent(values));
  };

  return (
    <Page title='Event | Aimaan-Project'>
      <Container>
        <EventForm handleSubmit={handleSubmit} />
      </Container>
    </Page>
  );
}

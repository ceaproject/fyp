import { useEffect, useState } from 'react';
// material
import {
  Card,
  Table,
  Stack,
  Avatar,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  TablePagination,
  Skeleton,
  IconButton,
  Button,
  Collapse,
  Box,
  TableHead,
} from '@mui/material';
// components
import Page from 'components/Page';
import Scrollbar from 'components/Scrollbar';
import SearchNotFound from 'components/SearchNotFound';
import { UserListHead, UserListToolbar } from 'components/user';
//
import { useToggleInput } from 'hooks';
import UserDetails from 'components/UserDetails';
import ConfirmDelete from 'components/dialogs/ConfirmDelete';
import { useDispatch, useSelector } from 'react-redux';
import {
  cancelEvent,
  deleteEvent,
  getAllEvents,
  handleBooking,
  registerEvent,
  updateEvent,
} from 'store/slices/events/extraReducers';
import { applySortFilter, getComparator } from 'components/table_reusables';
import { Link, useNavigate } from 'react-router-dom';
import Label from 'components/Label';
import {
  Cancel,
  Check,
  Delete,
  Edit,
  KeyboardArrowDown,
  KeyboardArrowUp,
} from '@mui/icons-material';
import plusFill from '@iconify/icons-eva/plus-fill';
import { Icon } from '@iconify/react';
import { addBooking, removeBooking } from 'store/slices/auth';
// ----------------------------------------------------------------------

const filterPopoverId = 'UserfilterPopOver';

const Row = ({
  user: loggedUser,
  row: event,
  handleEdit,
  handleDelete,
  bookings = [],
  handleRegister,
}) => {
  const { _id, title, info, image, video, links, type, coordinator } = event;

  const navigate = useNavigate();
  const [open, toggleOpen] = useToggleInput(false);
  const dispatch = useDispatch();

  const handleActive = (e) => {
    const { id: userId } = e.currentTarget.dataset;
    console.log('userId', userId);
    dispatch(
      handleBooking({ id: _id, updatedEvent: { userId: userId, status: true } })
    );
  };

  const handleBan = (e) => {
    const { id: userId } = e.currentTarget.dataset;
    console.log('userId', userId);
    dispatch(handleBooking({ id: _id, userId: userId, status: false }));
  };

  return (
    <>
      <TableRow key={_id} tabIndex={-1} role='checkbox'>
        <TableCell padding='checkbox'>
          <IconButton aria-label='expand row' size='small' onClick={toggleOpen}>
            {open ? <KeyboardArrowUp /> : <KeyboardArrowDown />}
          </IconButton>
        </TableCell>

        <TableCell component='th' scope='row' padding='none'>
          <Stack direction='row' alignItems='center' spacing={2}>
            <Avatar alt={image} src={image} />
            <Typography variant='subtitle2' noWrap>
              {title}
            </Typography>
          </Stack>
        </TableCell>
        <TableCell align='left'>{info}</TableCell>
        <TableCell align='left'>
          {coordinator ? (
            coordinator.name
          ) : (
            <Label color='error' variant='ghost'>
              Not Assigned
            </Label>
          )}
        </TableCell>
        <TableCell align='left'>{links.join(',')}</TableCell>
        <TableCell align='left'>{type}</TableCell>
        <TableCell align='left'>
          {loggedUser.role === 'member' ? (
            <Button
              data-id={_id}
              size='small'
              onClick={handleRegister}
              variant='outlined'
              color='success'
            >
              {Boolean(bookings.find((el) => el.event === _id))
                ? 'Cancel Booking'
                : 'Register'}
            </Button>
          ) : (
            <>
              <IconButton onClick={handleEdit} data-id={_id} color='primary'>
                <Edit />
              </IconButton>
              <IconButton onClick={handleDelete} data-id={_id} color='error'>
                <Delete />
              </IconButton>
            </>
          )}
        </TableCell>
      </TableRow>

      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
          <Collapse in={open} timeout='auto' unmountOnExit>
            <Box sx={{ margin: 1 }}>
              {event.users?.length ? (
                <>
                  <Typography variant='h6' gutterBottom component='div'>
                    Registered Users
                  </Typography>
                  <Table size='small' aria-label='purchases'>
                    <TableHead>
                      <TableRow>
                        <TableCell>Name</TableCell>
                        <TableCell>Email</TableCell>
                        <TableCell>Resume</TableCell>
                        <TableCell align='right'>Registration Date</TableCell>
                        {loggedUser.role !== 'member' && (
                          <TableCell align='right'>Actions</TableCell>
                        )}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {event.users.map(({ user, approved }) => (
                        <TableRow key={user._id}>
                          <TableCell component='th' scope='row'>
                            {user.name}
                          </TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>{user.resume}</TableCell>
                          <TableCell align='right'>
                            {new Date(event.createdAt).toDateString()}
                          </TableCell>

                          {loggedUser.role !== 'member' && (
                            <TableCell align='right'>
                              {approved === false ? (
                                <IconButton
                                  color='success'
                                  onClick={handleActive}
                                  data-id={user._id}
                                >
                                  <Check />
                                </IconButton>
                              ) : (
                                <IconButton
                                  color='error'
                                  onClick={handleBan}
                                  data-id={user._id}
                                >
                                  <Cancel />
                                </IconButton>
                              )}
                            </TableCell>
                          )}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </>
              ) : (
                <Typography variant='h6' fontWeight='normal'>
                  No Users Registered for this event
                </Typography>
              )}
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </>
  );
};

export default function Event({ filter }) {
  const { user, bookings } = useSelector((st) => st.auth);
  const { events, fetching } = useSelector((st) => st.events);
  console.log('events', events);
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState('asc');
  const [orderBy, setOrderBy] = useState('name');
  const [filterName, setFilterName] = useState('');
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [filteredEvents, setFilteredEvents] = useState([]);
  const [TABLE_HEAD, setTABLE_HEAD] = useState([
    { id: 'title', label: 'Title', alignRight: false },
    { id: 'info', label: 'Info', alignRight: false },
    { id: 'coordinator', label: 'Coordinator', alignRight: false },
    { id: 'links', label: 'Links', alignRight: false },
    { id: 'type', label: 'Type', alignRight: false },
    { id: 'actions', label: 'Actions', alignRight: false },
  ]);

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [isDetailsOpen, toggleDetails] = useToggleInput(false);
  const [detailsUser, setDetailsUser] = useState();

  const [isDeleteOpen, toggleDeleteOpen] = useToggleInput(false);
  const [currentDeleteId, setCurrentDeleteId] = useState();
  const [anchorEl, setAnchorEl] = useState(null);
  const isFilterOpen = Boolean(anchorEl);

  const handleDeleteButton = (e) => {
    e.stopPropagation();
    const { id } = e.currentTarget.dataset;
    console.log('id', id);
    setCurrentDeleteId(id);
    toggleDeleteOpen();
  };

  const handleDeleteUser = () => {
    dispatch(deleteEvent(currentDeleteId));
    toggleDeleteOpen();
  };

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (event) => {
    setFilterName(event.target.value);
  };

  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - events.length) : 0;

  useEffect(() => {
    if (!events) {
      dispatch(getAllEvents());
      return;
    }
  }, [events]);

  const handleEdit = (e) => {
    const { id } = e.currentTarget.dataset;
    navigate(id);
  };

  const handleDelete = (e) => {
    const { id } = e.currentTarget.dataset;
    dispatch(deleteEvent(id));
  };

  useEffect(() => {
    if (!events) {
      return;
    }

    if (fetching) return;

    let newUsers = applySortFilter(
      events,
      getComparator(order, orderBy),
      filterName,
      'title'
    );
    setFilteredEvents(newUsers);
  }, [events, fetching, order, orderBy, filterName, getComparator, filter]);

  const isUserNotFound = filteredEvents.length === 0;

  const handleClick = (event) => {
    console.log(`event`, event);
    setAnchorEl(event.currentTarget);
  };

  const handleRegister = (e) => {
    const { id } = e.currentTarget.dataset;
    console.log('id', id);
    if (Boolean(bookings.find((el) => el.event === id)))
      dispatch(cancelEvent(id)).then((res) => {
        console.log('res', res);
        dispatch(removeBooking(res.payload.booking._id));
      });
    else
      dispatch(registerEvent(id)).then((res) => {
        console.log('res', res);
        dispatch(addBooking(res.payload.booking));
      });
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleActive = (e) => {
    const { id } = e.currentTarget.dataset;

    console.log('id', id);
    dispatch(updateEvent({ id, updatedUser: { status: 'active' } }));
  };

  const handleBan = (e) => {
    const { id } = e.currentTarget.dataset;

    console.log('id', id);
    dispatch(updateEvent({ id, updatedUser: { status: 'ban' } }));
  };
  return (
    <Page title='Event | Aimaan-Project'>
      <Container>
        <Stack
          direction='row'
          alignItems='center'
          justifyContent='space-between'
          mb={2}
        >
          <Typography variant='h4' gutterBottom>
            Events
          </Typography>
          {console.log('user.role', user.role)}
          {(user.role === 'manager' || user.role === 'coordinator') && (
            <Button
              component={Link}
              to='new'
              variant='contained'
              startIcon={<Icon icon={plusFill} />}
            >
              New Event
            </Button>
          )}
        </Stack>

        <Card>
          <UserListToolbar
            numSelected={0}
            filterName={filterName}
            onFilterName={handleFilterByName}
            searchSlug='Search Events'
            filterPopoverId={filterPopoverId}
            handleClick={handleClick}
            handleClose={handleClose}
            noFilter
            showCSV
            data={filteredEvents}
          />

          <Scrollbar>
            <TableContainer sx={{ minWidth: 800 }}>
              <Table>
                <UserListHead
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={filteredEvents.length}
                  numSelected={0}
                  onRequestSort={handleRequestSort}
                />
                <TableBody>
                  {fetching
                    ? Array(5)
                        .fill()
                        .map((_, idx) => (
                          <TableRow key={idx}>
                            <TableCell>
                              <Skeleton variant='circular' />
                            </TableCell>
                            {Array(4)
                              .fill()
                              .map((_, idx) => (
                                <TableCell key={idx * 2}>
                                  <Skeleton />
                                </TableCell>
                              ))}
                          </TableRow>
                        ))
                    : filteredEvents
                        .slice(
                          page * rowsPerPage,
                          page * rowsPerPage + rowsPerPage
                        )
                        .map((row) => {
                          return (
                            <Row
                              handleEdit={handleEdit}
                              handleDelete={handleDelete}
                              bookings={bookings}
                              handleRegister={handleRegister}
                              row={row}
                              user={user}
                            />
                          );
                        })}
                  {emptyRows > 0 && (
                    <TableRow style={{ height: 53 * emptyRows }}>
                      <TableCell colSpan={6} />
                    </TableRow>
                  )}
                </TableBody>
                {isUserNotFound && (
                  <TableBody>
                    <TableRow>
                      <TableCell align='center' colSpan={12} sx={{ py: 3 }}>
                        <SearchNotFound searchQuery={filterName} />
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )}
              </Table>
            </TableContainer>
          </Scrollbar>

          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component='div'
            count={filteredEvents.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
          <UserDetails
            open={isDetailsOpen}
            toggleDialog={toggleDetails}
            event={detailsUser}
          />
          <ConfirmDelete
            open={isDeleteOpen}
            toggleDialog={toggleDeleteOpen}
            title='Delete This Event'
            handleSuccess={handleDeleteUser}
          />
        </Card>
      </Container>
    </Page>
  );
}

import { useEffect, useState } from 'react';
// material
import {
  Card,
  Table,
  Stack,
  Avatar,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  TablePagination,
  Skeleton,
  IconButton,
  Button,
  Select,
  MenuItem,
} from '@mui/material';
// components
import Page from 'components/Page';
import Scrollbar from 'components/Scrollbar';
import SearchNotFound from 'components/SearchNotFound';
import { UserListHead, UserListToolbar } from 'components/user';
import MessageIcon from '@mui/icons-material/Message';
import { useToggleInput } from 'hooks';
import UserDetails from 'components/UserDetails';
import ConfirmDelete from 'components/dialogs/ConfirmDelete';
import { useDispatch, useSelector } from 'react-redux';
import {
  deleteUser,
  getAllUsers,
  updateUser,
} from 'store/slices/users/extraReducers';
import { applySortFilter, getComparator } from 'components/table_reusables';
import { useNavigate } from 'react-router-dom';
import Label from 'components/Label';
import { Cancel, Check, Filter } from '@mui/icons-material';
import UserFilter from './Filter';
// ----------------------------------------------------------------------

const TABLE_HEAD = [
  { id: 'name', label: 'Name', alignRight: false },
  { id: 'email', label: 'Email', alignRight: false },
  { id: 'status', label: 'Status', alignRight: false },
  { id: 'Actions', label: 'Actions', alignRight: false },
];

const filterPopoverId = 'UserfilterPopOver';

export default function User({ filter }) {
  const { user } = useSelector((st) => st.auth);
  const { users, fetching } = useSelector((st) => st.users);
  console.log('users', users);
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState('asc');
  const [orderBy, setOrderBy] = useState('name');
  const [filterName, setFilterName] = useState('');
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [filteredUsers, setFilteredUsers] = useState([]);

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [isDetailsOpen, toggleDetails] = useToggleInput(false);
  const [detailsUser, setDetailsUser] = useState();

  const [isDeleteOpen, toggleDeleteOpen] = useToggleInput(false);
  const [currentDeleteId, setCurrentDeleteId] = useState();
  const [anchorEl, setAnchorEl] = useState(null);
  const isFilterOpen = Boolean(anchorEl);
  const [isUserFilterOpen, toggleFilterOpen] = useToggleInput(false);

  const handleDeleteButton = (e) => {
    e.stopPropagation();
    const { id } = e.currentTarget.dataset;
    console.log('id', id);
    setCurrentDeleteId(id);
    toggleDeleteOpen();
  };

  const handleDeleteUser = () => {
    dispatch(deleteUser(currentDeleteId));
    toggleDeleteOpen();
  };

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleChat = (event) => {
    navigate(`/dashboard/messages?user=${event.currentTarget.dataset.id}`);
  };

  const handleFilterByName = (event) => {
    setFilterName(event.target.value);
  };

  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - users.length) : 0;

  useEffect(() => {
    if (!users) {
      dispatch(getAllUsers());
      return;
    }

    if (fetching) return;

    let newUsers = applySortFilter(
      users,
      getComparator(order, orderBy),
      filterName,
      'name'
    );
    setFilteredUsers(newUsers);
  }, [users, fetching, order, orderBy, filterName, getComparator, filter]);

  const isUserNotFound = filteredUsers.length === 0;

  const handleClick = (event) => {
    console.log(`event`, event);
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleActive = (e) => {
    const { id } = e.currentTarget.dataset;

    console.log('id', id);
    dispatch(updateUser({ id, updatedUser: { status: 'active' } }));
  };

  const handleBan = (e) => {
    const { id } = e.currentTarget.dataset;

    console.log('id', id);
    dispatch(updateUser({ id, updatedUser: { status: 'ban' } }));
  };
  return (
    <Page title='User | Aimaan-Project'>
      <Container>
        <Stack
          direction='row'
          alignItems='center'
          justifyContent='space-between'
          mb={2}
        >
          <Typography variant='h4' gutterBottom>
            Users
          </Typography>
          {/* {user.role === 'admin' && filter === 'vendor' && (
            <Button
              component={Link}
              to="new"
              variant="contained"
              startIcon={<Icon icon={plusFill} />}
            >
              New User
            </Button>
          )} */}
          <Button
            variant='contained'
            startIcon={<Filter />}
            onClick={toggleFilterOpen}
          >
            Filter
          </Button>
        </Stack>
        <UserFilter
          setFilteredUsers={setFilteredUsers}
          open={isUserFilterOpen}
          toggleDialog={toggleFilterOpen}
          users={users}
        />

        <Card>
          <UserListToolbar
            numSelected={0}
            filterName={filterName}
            onFilterName={handleFilterByName}
            searchSlug='Search Users'
            filterPopoverId={filterPopoverId}
            handleClick={handleClick}
            handleClose={handleClose}
            noFilter
            showCSV
            data={filteredUsers}
          />

          <Scrollbar>
            <TableContainer sx={{ minWidth: 800 }}>
              <Table>
                <UserListHead
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={filteredUsers.length}
                  numSelected={0}
                  onRequestSort={handleRequestSort}
                />
                <TableBody>
                  {fetching
                    ? Array(5)
                        .fill()
                        .map((_, idx) => (
                          <TableRow key={idx}>
                            <TableCell>
                              <Skeleton variant='circular' />
                            </TableCell>
                            {Array(4)
                              .fill()
                              .map((_, idx) => (
                                <TableCell key={idx * 2}>
                                  <Skeleton />
                                </TableCell>
                              ))}
                          </TableRow>
                        ))
                    : filteredUsers
                        .slice(
                          page * rowsPerPage,
                          page * rowsPerPage + rowsPerPage
                        )
                        .map((row) => {
                          const { _id, name, status, email, photo } = row;

                          return (
                            <TableRow
                              onClick={() => {
                                if (filter === 'vendor') {
                                  navigate(_id);
                                }
                              }}
                              hover
                              key={_id}
                              tabIndex={-1}
                              role='checkbox'
                              sx={(theme) => ({
                                '&.MuiTableRow-root': {
                                  cursor: filter === 'vendor' && 'pointer',
                                  textDecoration: 'none',
                                },
                              })}
                            >
                              <TableCell padding='checkbox'>
                                {/* <Checkbox
                              checked={isItemSelected}
                              onChange={(event) => handleClick(event, name)}
                            /> */}
                              </TableCell>
                              <TableCell
                                component='th'
                                scope='row'
                                padding='none'
                              >
                                <Stack
                                  direction='row'
                                  alignItems='center'
                                  spacing={2}
                                >
                                  <Avatar alt={name} src={photo} />
                                  <Typography variant='subtitle2' noWrap>
                                    {name}
                                  </Typography>
                                </Stack>
                              </TableCell>
                              <TableCell align='left'>{email}</TableCell>
                              {/* <TableCell align="left">{role}</TableCell> */}
                              <TableCell align='left'>
                                <Label
                                  variant='ghost'
                                  color={status === 'ban' ? 'error' : 'success'}
                                >
                                  {status}
                                </Label>
                              </TableCell>

                              <TableCell align='left'>
                                {/* <UserMoreMenu /> */}
                                {user.role === 'admin' && (
                                  <Select
                                    label='role'
                                    size='small'
                                    defaultValue={row.role}
                                    onChange={(e) =>
                                      dispatch(
                                        updateUser({
                                          id: row._id,
                                          updatedUser: {
                                            role: e.target.value,
                                          },
                                        })
                                      )
                                    }
                                  >
                                    <MenuItem value={row.role}>
                                      {row.role}
                                    </MenuItem>
                                    {['manager', 'member', 'coordinator']
                                      .filter((el) => el !== user.role)
                                      .map((el) => (
                                        <MenuItem value={el}>{el}</MenuItem>
                                      ))}
                                  </Select>
                                )}
                                {row.role !== 'admin' &&
                                  (user.role === 'admin' ||
                                    user.role === 'manager') && (
                                    <>
                                      {status === 'ban' ? (
                                        <IconButton
                                          color='success'
                                          onClick={handleActive}
                                          data-id={row._id}
                                        >
                                          <Check />
                                        </IconButton>
                                      ) : (
                                        <IconButton
                                          color='error'
                                          onClick={handleBan}
                                          data-id={row._id}
                                        >
                                          <Cancel />
                                        </IconButton>
                                      )}
                                    </>
                                  )}
                                {row._id !== user._id && (
                                  <IconButton
                                    color='primary'
                                    onClick={handleChat}
                                    data-id={row._id}
                                  >
                                    <MessageIcon />
                                  </IconButton>
                                )}
                              </TableCell>
                            </TableRow>
                          );
                        })}
                  {emptyRows > 0 && (
                    <TableRow style={{ height: 53 * emptyRows }}>
                      <TableCell colSpan={6} />
                    </TableRow>
                  )}
                </TableBody>
                {isUserNotFound && (
                  <TableBody>
                    <TableRow>
                      <TableCell align='center' colSpan={12} sx={{ py: 3 }}>
                        <SearchNotFound searchQuery={filterName} />
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )}
              </Table>
            </TableContainer>
          </Scrollbar>

          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component='div'
            count={filteredUsers.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
          <UserDetails
            open={isDetailsOpen}
            toggleDialog={toggleDetails}
            user={detailsUser}
          />
          <ConfirmDelete
            open={isDeleteOpen}
            toggleDialog={toggleDeleteOpen}
            title='Delete This User'
            handleSuccess={handleDeleteUser}
          />
        </Card>
      </Container>
    </Page>
  );
}

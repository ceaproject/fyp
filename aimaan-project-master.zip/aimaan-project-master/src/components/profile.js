// material
import { Button, Container, Grid, TextField, Typography } from '@mui/material';
// components
import Page from 'components/Page';
import { useDispatch, useSelector } from 'react-redux';
import * as Yup from 'yup';
//import * as Yup from 'yup';
import { useFormik } from 'formik';
import { FormikAutoComplete, FormikTextField } from 'components/formik';
import { Add, Save } from '@mui/icons-material';
import { toast } from 'react-toastify';
import { getMuiDateFormat } from 'helpers/muiHelpers';
import { useEffect, useState } from 'react';
import { updateMe } from 'store/slices/auth/extraReducers';
import LocationAutoComplete from './LocationAutocomplete';

// ----------------------------------------------------------------------

export default function Profile() {
  const { user, loading } = useSelector((st) => st.auth);
  const dispatch = useDispatch();
  const [resume, setResume] = useState('');

  const validationSchema = Yup.object().shape({
    passport: Yup.string(),
    name: Yup.string().required('Name is required'),
    email: Yup.string().required('Email is required'),
    dateOfBirth: Yup.string(),
    contact: Yup.number().required('Contact is required'),
    jobPosition: Yup.string().required('JobPosition is required'),
    education: Yup.string().required('Education is required'),
    studyField: Yup.string().required('StudyField is required'),
    location: Yup.string(),
    age: Yup.number().required('Age is Required!'),
  });

  const formik = useFormik({
    initialValues: {
      passport: '',
      name: '',
      email: '',
      dateOfBirth: '',
      contact: '',
      jobPosition: '',
      education: '',
      studyField: '',
      location: '',
      age: '',
      gender: 'male',
    },
    validationSchema: validationSchema,
    onSubmit: () => {
      console.log(`'formik.va'`, formik.values);
      handleSubmit({ ...formik.values });
    },
  });
  const { errors, touched, values, isSubmitting, getFieldProps } = formik;

  useEffect(() => {
    formik.setValues({
      passport: user.passport,
      name: user.name,
      email: user.email,
      dateOfBirth: getMuiDateFormat(user.dateOfBirth),
      contact: user.contact,
      jobPosition: user.jobPosition,
      education: user.education,
      studyField: user.studyField,
      location: user.location,
      resume: user.resume,
      gender: user.gender,
      age: user.age,
    });
  }, [user]);

  const handleResume = (e) => {
    setResume(e.target.files[0]);
  };

  const handleSubmit = (values) => {
    console.log('values', values);
    dispatch(updateMe(values));
  };
  const handleForm = async () => {
    console.log('formik.values', formik.values);
    dispatch(updateMe({ ...formik.values, resume }));
  };

  return (
    <Page title='Profile | Aimaan-Project'>
      <Container
        sx={{
          maxWidth: '900px !important',
          '& .MuiFormControl-root': {
            marginBottom: 3,
          },
        }}
      >
        <Typography variant='h5' align='center' sx={{ mb: 2 }}>
          Profile
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <FormikTextField name='name' formik={formik} fullWidth />
            <FormikTextField
              name='email'
              type='email'
              formik={formik}
              fullWidth
            />
            <FormikTextField
              name='dateOfBirth'
              type='date'
              formik={formik}
              fullWidth
            />
            <FormikTextField
              name='contact'
              type='number'
              formik={formik}
              fullWidth
            />
            <FormikTextField
              name='age'
              type='number'
              formik={formik}
              fullWidth
            />
            <LocationAutoComplete formik={formik} />
          </Grid>{' '}
          <Grid item xs={12} sm={6}>
            <FormikTextField name='passport' formik={formik} fullWidth />
            <FormikTextField name='jobPosition' formik={formik} fullWidth />
            <FormikAutoComplete
              name='gender'
              formik={formik}
              fullWidth
              options={['male', 'female']}
            />
            <FormikAutoComplete
              name='education'
              formik={formik}
              fullWidth
              options={[
                'hs',
                'certificate',
                'diploma',
                'degree',
                'masters',
                'other',
              ]}
            />
            <FormikAutoComplete
              name='studyField'
              formik={formik}
              fullWidth
              options={[
                'ICT',
                'Engineering',
                'Business',
                'Service',
                'Homecare',
                'Medical',
                'Education',
                'Others',
              ]}
            />
          </Grid>
        </Grid>
        <div style={{ textAlign: 'right' }}>
          <div style={{ textAlign: 'left' }}>
            <label htmlFor='resume' style={{ marginRight: '1rem' }}>
              Resume
            </label>
            <input
              id='resume'
              label='resume'
              variant='outlined'
              type='file'
              onChange={handleResume}
              // style={{ display: 'none' }}
            />
          </div>
          <Button
            disabled={!formik.dirty || !formik.isValid || formik.isSubmitting}
            size='medium'
            variant='contained'
            onClick={handleForm}
            endIcon={<Save />}
          >
            Save
          </Button>
        </div>
      </Container>
    </Page>
  );
}

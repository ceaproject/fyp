import React, { useContext, useState } from 'react';
import Avatar from '@mui/material/Avatar';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import { styled } from '@mui/material/styles';

// import styles from './style';
// import image from 'Assets/one-removebg-preview.png';
import image from 'images/five-removebg-preview.png';

import { toast } from 'react-toastify';
import sizes from './sizes';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';

const PREFIX = 'ForgotPass';

const classes = {
  root: `${PREFIX}-root`,
  avatar: `${PREFIX}-avatar`,
  sectionReg: `${PREFIX}-sectionReg`,
  selectLabel: `${PREFIX}-selectLabel`,
  selectContainer: `${PREFIX}-selectContainer`,
  containerReg: `${PREFIX}-containerReg`,
  user: `${PREFIX}-user`,
  imgBx: `${PREFIX}-imgBx`,
  formBx: `${PREFIX}-formBx`,
  link: `${PREFIX}-link`,
  signupBx: `${PREFIX}-signupBx`,
  signinBx: `${PREFIX}-signinBx`,
  isActive: `${PREFIX}-isActive`,
  active: `${PREFIX}-active`,
};
const Root = styled('div')(({ theme }) => ({
  [`&.${classes.root}`]: {
    margin: 0,
    padding: 0,
    boxSizing: 'border-box',
    fontFamily: '"Poppins" , "sans-serif"',
  },

  [`& .${classes.avatar}`]: {
    backgroundColor: '#06C6FF',
    // backgroundColor: '#677EFF',
  },

  [`& .${classes.sectionReg}`]: {
    position: 'relative',
    minHeight: '100vh',
    backgroundColor: '#fff',
    display: 'flex',
    justifyContent: 'center',
    // alignItems: 'center',
    padding: 20,
    paddingTop: '2rem',
  },
  [`& .${classes.selectLabel}`]: {
    fontSize: '14px !important',
    textAlign: 'left !important',
    display: 'unset !important',
    textTransform: 'unset !important',
    marginRight: '1rem !important',
  },
  [`& .${classes.selectContainer}`]: {
    display: 'flex',
    justifyContent: 'space-between',
    '& option': {
      cursor: 'pointer',
      background: '#f5f5f5',
      color: '#333',
    },
    '& select': {
      position: 'relative',
      width: '100%',
      padding: 10,
      background: '#f5f5f5',
      color: '#333',
      border: 'none',
      outline: 'none',
      boxShadow: 'none',
      margin: '8px 0',
      fontSize: 14,
      letterSpacing: 1,
      fontWeight: 300,
    },
  },

  [`& .${classes.containerReg}`]: {
    position: 'relative',
    width: 800,
    background: '#fff',
    boxShadow: '0 15px 50px rgba(0, 0, 0, 0.1)',
    overflow: 'hidden',
    pointerEvents: 'initial',
    border: '1px solid #ccc',
  },

  [`& .${classes.user}`]: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    display: 'flex',
  },

  [`& .${classes.imgBx}`]: {
    position: 'relative',
    width: '50%',
    height: '100%',
    background: '#fff',
    transition: '2.5s',
    '& img': {
      position: 'absolute',
      top: '50%',
      left: '25%',
      width: '85%',
      height: '50%',
      objectFit: 'cover',
      transform: 'translate(-20%, -50%)',
    },

    [sizes.down('md')]: {
      display: 'none',
    },
  },

  [`& .${classes.formBx}`]: {
    position: 'relative',
    width: '50%',
    height: '100%',
    background: '#fff',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
    transition: '2.5s',
    flexDirection: 'column',

    '& form h2': {
      fontSize: 18,
      fontWeight: 600,
      textTransform: 'uppercase',
      letterSpacing: 2,
      textAlign: 'center',
      width: '100%',
      marginBottom: 10,
      color: '#555',
    },

    '& form input': {
      position: 'relative',
      width: '100%',
      padding: 10,
      background: '#f5f5f5',
      color: '#333',
      border: 'none',
      outline: 'none',
      boxShadow: 'none',
      margin: '8px 0',
      fontSize: 14,
      letterSpacing: 1,
      fontWeight: 300,
    },

    '& form input[type="submit"]': {
      borderRadius: 20,
      maxWidth: 100,
      background: '#06C6FF',
      color: '#fff',
      cursor: 'pointer',
      fontSize: 14,
      fontWeight: 500,
      letterSpacing: 1,
      transition: '2.5s',
    },

    [sizes.down('md')]: {
      width: '100%',
    },
  },

  [`& .${classes.link}`]: {
    position: 'relative',
    marginTop: 20,
    fontSize: 12,
    letterSpacing: 1,
    color: '#555',
    textTransform: 'uppercase',
    fontWeight: 300,

    '& a': {
      fontWeight: 600,
      textDecoration: 'none',
      color: '#06C6FF',
      marginLeft: 10,
      fontSize: 13,
      cursor: 'pointer',
    },
  },

  [`& .${classes.signupBx}`]: {
    // pointerEvents: 'none',

    '& formBx': {
      left: '100%',
    },

    '& imgBx': {
      left: '-100%',
    },
  },

  [`& .${classes.signinBx}`]: {
    '& formBx': {
      left: '0%',
    },

    '& imgBx': {
      left: '0%',
    },
  },

  [`& .${classes.isActive}`]: {
    // pointerEvents: 'initial',
    color: 'white',
    width: '100%',
    height: '100%',
  },

  [`& .${classes.active}`]: {
    // pointerEvents: 'initial',
    color: 'white',
    '& signupBx': {
      // pointerEvents: 'initial',

      '& formBx': {
        left: 0,
      },

      '& imgBx': {
        left: '0%',
      },
    },

    '& signinBx': {
      '& formBx': {
        left: '100%',
      },

      '& imgBx': {
        left: '-100%',
      },
    },
  },
}));

const ResetPass = (props) => {
  const initialState = {
    password: '',
    passwordConfirm: '',
  };

  const navigate = useNavigate();
  const { resetToken } = useParams();

  const [logState, setLogState] = useState(initialState);

  const handleTxtChange = (e) => {
    setLogState({
      ...logState,
      [e.target.name]: e.target.value,
    });
  };

  const resetState = () => {
    setLogState(initialState);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(`logState`, logState);

    try {
      const res = await axios.patch(
        `${API_BASE_URL}/auth/resetPassword/${resetToken}`,
        {
          ...logState,
        }
      );
      console.log(`res`, res);
      toast.success(res.data.message);

      resetState();

      setTimeout(() => {
        navigate('/');
      }, 1500);
    } catch (err) {
      console.log(`err`, err);
      let msg = 'Something Went Wrong';
      if (err.response && err.response.data) msg = err.response.data.message;

      toast.error(msg);

      setTimeout(() => {
        navigate('/forgot');
      }, 3000);
    }
  };

  return (
    <Root className={classes.root}>
      <section className={classes.sectionReg}>
        <div className={`${classes.containerReg}`}>
          <div className={`${classes.user} ${classes.signinBx}`}>
            <div className={classes.imgBx}>
              <img src={image} alt='Signin' />
            </div>
            <div className={classes.formBx}>
              <Avatar className={classes.avatar}>
                <LockOutlinedIcon />
              </Avatar>
              <form onSubmit={handleSubmit}>
                <h2>Reset Password</h2>
                <input
                  value={logState.password}
                  onChange={handleTxtChange}
                  type='password'
                  name='password'
                  placeholder='New Password'
                  autoComplete='false'
                />
                <input
                  value={logState.passwordConfirm}
                  onChange={handleTxtChange}
                  type='password'
                  name='passwordConfirm'
                  placeholder='Confirm Password'
                  autoComplete='false'
                />

                <input
                  type='submit'
                  name=''
                  value='Update Password'
                  style={{
                    width: 'fit-content',
                    padding: '10px 25px',
                    maxWidth: 'unset',
                  }}
                />

                <p className={classes.link}>
                  Don't have an account ?
                  <a
                    type='button'
                    name='Reg'
                    href='/account'
                    onClick={(e) => {
                      e.preventDefault();
                      navigate('/account');
                    }}
                  >
                    Login
                  </a>
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>
    </Root>
  );
};

export default ResetPass;

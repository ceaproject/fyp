import React, { useContext, useEffect, useState } from 'react';
import Avatar from '@mui/material/Avatar';
import LockOutlinedIcon from '@mui/icons-material/Lock';
// import image from 'Assets/one-removebg-preview.png';
import image from 'images/five-removebg-preview.png';
import { useDispatch, useSelector } from 'react-redux';

import { toast } from 'react-toastify';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { login } from 'store/slices/auth/extraReducers';
import { getMyBookings } from 'store/slices/users/extraReducers';
// import { AuthContext } from 'Contexts/AuthContext';
// import { API_BASE_URL } from 'Utils/constants';

const Login = (props) => {
  const initialState = {
    email: '',
    password: '',
  };
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { isLoggedIn, loading } = useSelector((st) => st.auth);

  const [logState, setLogState] = useState(initialState);
  // const { signInUser } = useContext(AuthContext);

  const handleTxtChange = (e) => {
    setLogState({
      ...logState,
      [e.target.name]: e.target.value,
    });
  };

  useEffect(() => {
    if (isLoggedIn) navigate(window.location.search || '/');
  }, [isLoggedIn, navigate]);

  const resetState = () => setLogState(initialState);

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(`logState`, logState);

    dispatch(login({ ...logState })).then(({ err }) => {
      console.log('err', err);
      if (!err) dispatch(getMyBookings());
    });
  };

  const { classes, history } = props;
  return (
    <div className={`${classes.user} ${classes.signinBx}`}>
      <div className={classes.imgBx}>
        <img src={image} alt='Signin' />
      </div>
      <div className={classes.formBx}>
        <Avatar className={classes.avatar}>
          <LockOutlinedIcon />
        </Avatar>
        <form onSubmit={handleSubmit}>
          <h2>Sign In</h2>
          <input
            value={logState.email}
            onChange={handleTxtChange}
            type='text'
            name='email'
            placeholder='Email'
            autoComplete='false'
          />
          <input
            value={logState.password}
            onChange={handleTxtChange}
            type='password'
            name='password'
            placeholder='Password'
            autoComplete='false'
          />
          <p
            onClick={() => navigate('/forgot')}
            style={{
              cursor: 'pointer',
              display: 'flex',
              justifyContent: 'flex-end',
            }}
          >
            <a
              type='button'
              name='Reg'
              style={{
                fontWeight: 600,
                textDecoration: 'none',
                color: '#06C6FF',
                marginLeft: 10,
                fontSize: 13,
                cursor: 'pointer',
              }}
            >
              Forgot Your Password ?
            </a>
          </p>
          <input type='submit' name='' value='Login' />

          <p className={classes.link}>
            Don't have an account ?
            <a type='button' name='Reg' onClick={props.handleChange}>
              Sign Up
            </a>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Login;

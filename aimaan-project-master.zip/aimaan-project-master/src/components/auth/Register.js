import React, { useEffect, useState } from 'react';
import styles from './style';
import Avatar from '@mui/material/Avatar';
import LockOutlinedIcon from '@mui/icons-material/Lock';

import image from 'images/five-removebg-preview.png';
// import image from 'Assets/one-removebg-preview.png';
import { toast } from 'react-toastify';
import axios from 'axios';
import { getMuiDateFormat } from 'helpers/muiHelpers';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { signUp } from 'store/slices/auth/extraReducers';

function Register(props) {
  const { classes } = props;
  const { isLoggedIn, loading } = useSelector((st) => st.auth);

  const initialState = {
    name: '',
    email: '',
    password: '',
    passwordConfirm: '',
    passport: '',
    dateOfBirth: getMuiDateFormat(new Date()),
    contact: '',
    jobPosition: '',
    education: '',
    studyField: '',
    gender: '',
  };

  const [state, setState] = useState(initialState);

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handleRegTxtChange = (e) => {
    setState({
      ...state,
      [e.target.name]: e.target.value,
    });
  };
  useEffect(() => {
    if (isLoggedIn) navigate(window.location.search || '/');
  }, [isLoggedIn, navigate]);

  const resetState = () => setState(initialState);

  const handleSubmit = async (e) => {
    console.log('Form Submitted');
    e.preventDefault();
    console.log(`state`, state);

    if (state.password !== state.passwordConfirm) {
      toast.error('Passwords NOT matched');
      return;
    }

    dispatch(signUp({ ...state }));
  };

  return (
    <div className={`${classes.user} ${classes.signupBx}`}>
      <div className={classes.formBx}>
        <Avatar className={classes.avatar}>
          <LockOutlinedIcon />
        </Avatar>
        <form onSubmit={handleSubmit}>
          <h2>Create an account</h2>
          <input
            type='text'
            name='name'
            placeholder='Name'
            value={state.name}
            onChange={handleRegTxtChange}
            autoComplete='false'
          />
          <input
            onChange={handleRegTxtChange}
            type='email'
            name='email'
            placeholder='Email Address'
            value={state.email}
            autoComplete='false'
          />
          <input
            onChange={handleRegTxtChange}
            type='password'
            name='password'
            placeholder='Password'
            value={state.password}
            autoComplete='false'
          />
          <input
            onChange={handleRegTxtChange}
            type='password'
            name='passwordConfirm'
            value={state.passwordConfirm}
            placeholder='Confirm Password'
            autoComplete='false'
          />
          <input
            onChange={handleRegTxtChange}
            type='number'
            name='contact'
            value={state.contact}
            placeholder='Contact'
            autoComplete='false'
          />
          <input
            onChange={handleRegTxtChange}
            type='text'
            name='jobPosition'
            value={state.jobPosition}
            placeholder='Job Position'
            autoComplete='false'
          />
          <label htmlFor='dateOfBirth'>Date of Birth</label>
          <input
            onChange={handleRegTxtChange}
            type='date'
            id='dateOfBirth'
            name='dateOfBirth'
            value={state.dateOfBirth}
            placeholder='Date of Birth'
            autoComplete='false'
          />
          <div className={classes.selectContainer}>
            <label for='education'>
              <h2 className={classes.selectLabel}>Gender</h2>
            </label>
            <select
              name='gender'
              id='gender'
              value={state.gender}
              onChange={handleRegTxtChange}
            >
              <option value='male'>Male</option>
              <option value='female'>Female</option>
            </select>
          </div>
          <br />
          <div className={classes.selectContainer}>
            <label for='education'>
              <h2 className={classes.selectLabel}>Highest Qualifiation</h2>
            </label>
            <select
              name='education'
              id='education'
              value={state.education}
              onChange={handleRegTxtChange}
            >
              <option value='hs'>Hs</option>
              <option value='certificate'>Certificate</option>
              <option value='diploma'>Diploma</option>
              <option value='degree'>Degree</option>
              <option value='masters'>Masters</option>
              <option value='other'>Other</option>
            </select>
          </div>
          <br />

          <div className={classes.selectContainer}>
            <label for='education'>
              {' '}
              <h2 className={classes.selectLabel}>Study Field</h2>
            </label>
            <select
              name='studyField'
              id='studyField'
              value={state.studyField}
              onChange={handleRegTxtChange}
            >
              <option value='ICT'>ICT</option>
              <option value='Engineering'>Engineering</option>
              <option value='Business'>Business</option>
              <option value='Service'>Service</option>
              <option value='Homecare'>Homecare</option>
              <option value='Medical'>Medical</option>
              <option value='Education'>Education</option>
              <option value='Others'>Others</option>
            </select>
          </div>
          <br />
          <input type='submit' name='' value='Sign Up' />
          <p className={classes.link}>
            Already have an account ?
            <a name='login' onClick={props.handleChange}>
              Sign In
            </a>
          </p>
        </form>
      </div>
      <div className={classes.imgBx}>
        <img src={image} alt='' />
      </div>
    </div>
  );
}

export default Register;

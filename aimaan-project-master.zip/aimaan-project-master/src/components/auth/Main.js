import React, { useState } from 'react';
import { styled } from '@mui/material/styles';
import Login from './Login';

import Register from './Register';
import sizes from './sizes';
const PREFIX = 'Main';

const classes = {
  root: `${PREFIX}-root`,
  avatar: `${PREFIX}-avatar`,
  sectionReg: `${PREFIX}-sectionReg`,
  selectLabel: `${PREFIX}-selectLabel`,
  selectContainer: `${PREFIX}-selectContainer`,
  containerReg: `${PREFIX}-containerReg`,
  user: `${PREFIX}-user`,
  imgBx: `${PREFIX}-imgBx`,
  formBx: `${PREFIX}-formBx`,
  link: `${PREFIX}-link`,
  signupBx: `${PREFIX}-signupBx`,
  signinBx: `${PREFIX}-signinBx`,
  isActive: `${PREFIX}-isActive`,
  active: `${PREFIX}-active`,
};

const Root = styled('div')(({ theme }) => ({
  [`&.${classes.root}`]: {
    margin: 0,
    padding: 0,
    boxSizing: 'border-box',
    fontFamily: '"Poppins" , "sans-serif"',
  },

  [`& .${classes.avatar}`]: {
    backgroundColor: '#06C6FF',
    // backgroundColor: '#677EFF',
  },

  [`& .${classes.sectionReg}`]: {
    position: 'relative',
    minHeight: '100vh',
    backgroundColor: '#fff',
    display: 'flex',
    justifyContent: 'center',
    // alignItems: 'center',
    padding: 20,
    paddingTop: '2rem',
  },
  [`& .${classes.selectLabel}`]: {
    fontSize: '14px !important',
    textAlign: 'left !important',
    display: 'unset !important',
    textTransform: 'unset !important',
    marginRight: '1rem !important',
  },
  [`& .${classes.selectContainer}`]: {
    display: 'flex',
    justifyContent: 'space-between',
    '& option': {
      cursor: 'pointer',
      background: '#f5f5f5',
      color: '#333',
    },
    '& select': {
      position: 'relative',
      width: '100%',
      padding: 10,
      background: '#f5f5f5',
      color: '#333',
      border: 'none',
      outline: 'none',
      boxShadow: 'none',
      margin: '8px 0',
      fontSize: 14,
      letterSpacing: 1,
      fontWeight: 300,
    },
  },

  [`& .${classes.containerReg}`]: {
    position: 'relative',
    width: 800,
    background: '#fff',
    boxShadow: '0 15px 50px rgba(0, 0, 0, 0.1)',
    overflow: 'hidden',
    pointerEvents: 'initial',
    border: '1px solid #ccc',
  },

  [`& .${classes.user}`]: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    display: 'flex',
  },

  [`& .${classes.imgBx}`]: {
    position: 'relative',
    width: '50%',
    height: '100%',
    background: '#fff',
    transition: '2.5s',
    '& img': {
      position: 'absolute',
      top: '50%',
      left: '25%',
      width: '85%',
      height: '50%',
      objectFit: 'cover',
      transform: 'translate(-20%, -50%)',
    },

    [sizes.down('md')]: {
      display: 'none',
    },
  },

  [`& .${classes.formBx}`]: {
    position: 'relative',
    width: '50%',
    height: '100%',
    background: '#fff',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
    transition: '2.5s',
    flexDirection: 'column',

    '& form h2': {
      fontSize: 18,
      fontWeight: 600,
      textTransform: 'uppercase',
      letterSpacing: 2,
      textAlign: 'center',
      width: '100%',
      marginBottom: 10,
      color: '#555',
    },

    '& form input': {
      position: 'relative',
      width: '100%',
      padding: 10,
      background: '#f5f5f5',
      color: '#333',
      border: 'none',
      outline: 'none',
      boxShadow: 'none',
      margin: '8px 0',
      fontSize: 14,
      letterSpacing: 1,
      fontWeight: 300,
    },

    '& form input[type="submit"]': {
      borderRadius: 20,
      maxWidth: 100,
      background: '#06C6FF',
      color: '#fff',
      cursor: 'pointer',
      fontSize: 14,
      fontWeight: 500,
      letterSpacing: 1,
      transition: '2.5s',
    },

    [sizes.down('md')]: {
      width: '100%',
    },
  },

  [`& .${classes.link}`]: {
    position: 'relative',
    marginTop: 20,
    fontSize: 12,
    letterSpacing: 1,
    color: '#555',
    textTransform: 'uppercase',
    fontWeight: 300,

    '& a': {
      fontWeight: 600,
      textDecoration: 'none',
      color: '#06C6FF',
      marginLeft: 10,
      fontSize: 13,
      cursor: 'pointer',
    },
  },

  [`& .${classes.signupBx}`]: {
    // pointerEvents: 'none',

    '& formBx': {
      left: '100%',
    },

    '& imgBx': {
      left: '-100%',
    },
  },

  [`& .${classes.signinBx}`]: {
    '& formBx': {
      left: '0%',
    },

    '& imgBx': {
      left: '0%',
    },
  },

  [`& .${classes.isActive}`]: {
    // pointerEvents: 'initial',
    color: 'white',
    width: '100%',
    height: '100%',
  },

  [`& .${classes.active}`]: {
    // pointerEvents: 'initial',
    color: 'white',
    '& signupBx': {
      // pointerEvents: 'initial',

      '& formBx': {
        left: 0,
      },

      '& imgBx': {
        left: '0%',
      },
    },

    '& signinBx': {
      '& formBx': {
        left: '100%',
      },

      '& imgBx': {
        left: '-100%',
      },
    },
  },
}));

function Main(props) {
  const [toggleForm, setToggleForm] = useState('login');
  const handleChange = (e) => {
    console.log(`e.target`, e.target);
    console.log(`e.target.name`, e.target.name);
    setToggleForm(e.target.name);
  };

  return (
    <Root className={classes.root}>
      <section className={classes.sectionReg}>
        <div
          className={`${classes.containerReg}`}
          style={{
            height: toggleForm !== 'login' && 800,
          }}
        >
          {toggleForm === 'login' ? (
            <Login handleChange={handleChange} classes={classes} />
          ) : (
            <Register handleChange={handleChange} classes={classes} />
          )}
        </div>
      </section>
    </Root>
  );
}

export default Main;

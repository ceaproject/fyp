import React from 'react';
import './research.css';
import '../../App.css';

const Research = () => {
  return (
    <div>
      {/* <!-- research process section starts from here --> */}
      <div className='research' id='research'>
        <div className='left'>
          <li>Harness the power of data & analytics</li>
          <p>
            Data and technology is at the core of everything we do. We leverage
            our expansive proprietary data to develop meaningful insights. We
            know the right questions to ask, and we know where to look to help
            you find the answers.
          </p>
          <li>Advance diversity & inclusion</li>
          <p>
            Our insights reveal the importance of diverse talent and uncover the
            roadblocks that stand in your way to building an inclusive culture.
            We give you the tools to advance your organization’s talent and
            showcase its potential.
          </p>
          <li>Activate transformation</li>
          <p>
            Our research provides the critical factors that make great
            transformations flourish as the world evolves in uncertain ways. We
            help you and your organization activate the levers to successfully
            transform and drive extraordinary growth.
          </p>
          <li>Define leadership of the future</li>
          <p>
            In todays increasingly disruptive environment, we have uncovered the
            profile of the leader of the future. We know which future-focused
            leadership qualities correlate with an organization’s ability to
            innovate.
          </p>
          <li>Coin a new language for talent and work</li>
          <p>
            Underpinned by our research, we developed the StarTech ACI Model – a
            unified framework encompassing the full breadth and depth of all
            StarTech IP, covering individuals, teams, organizations and society.
            This framework helps organizations explore and understand what it
            takes to maximize performance, power transformation, and drive
            results.
          </p>
        </div>
        <div className='right'>
          <div className='section-heading-2'>
            <h1>Our Research Process</h1>
            <p>
              The StarTech Institute is a trusted expert in solving current and
              future challenges. The work we do is widespread—below is just a
              sample of how we can help you accomplish your goals.
            </p>
          </div>
          <img src='images/research.png' alt='img' />
        </div>
      </div>
      {/* <!-- research process section ends here --> */}
    </div>
  );
};

export default Research;

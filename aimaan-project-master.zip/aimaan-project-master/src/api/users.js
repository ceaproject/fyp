import { getSECURE_API, API, baseURL, TOKEN_KEY } from 'api';
import axios from 'axios';

const SECURE_API = getSECURE_API();
SECURE_API.interceptors.request.use((req) => {
  req.baseURL = `${req.baseURL}/users`;
  return req;
});

// API.interceptors.request.use((req) => {
//   req.baseURL = `${req.baseURL}/users`;
//   return req;
// });

export const getAll = () => SECURE_API.get('/');
export const getMe = () => SECURE_API.get('/me');
export const getMyBookings = () => SECURE_API.get('/bookings');

export const updateMe = (profile) => {
  const formData = new FormData();
  for (const [key, value] of Object.entries(profile)) {
    console.log(`${key}: ${value}`);
    formData.append(key, value);
  }

  return fetch(`${baseURL}/users/me`, {
    body: formData,
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${localStorage.getItem(TOKEN_KEY)}`,
    },
  }).then(async (res) => {
    if (res.ok) return await res.json();
    else return Promise.reject(res.error);
    // callBack?.();
  });
};

export const updatePassword = (body) =>
  axios.patch(
    `${baseURL}/auth/update-password`,
    {
      ...body,
    },
    {
      headers: {
        Authorization: `Bearer ${localStorage.getItem(TOKEN_KEY)}`,
      },
    }
  );
export const updateOne = ({ id, updatedUser }) =>
  SECURE_API.patch(`/${id}`, {
    ...updatedUser,
  });
export const deleteOne = (id) => SECURE_API.delete(`/${id}`);

export const logIn = (values) => API.post('/auth/login', values);
export const signUp = (values) => API.post('/auth/signup', values);

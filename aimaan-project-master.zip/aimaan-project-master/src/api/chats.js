import { getSECURE_API, API, baseURL, TOKEN_KEY } from 'api';
import axios from 'axios';

const SECURE_API = getSECURE_API();
SECURE_API.interceptors.request.use((req) => {
  req.baseURL = `${req.baseURL}/chats`;
  return req;
});

export const getAll = () => SECURE_API.get('/me');
export const createNew = (userId) =>
  SECURE_API.post('/', {
    receiver: userId,
  });

export const deleteOne = (id) => SECURE_API.delete(`/${id}`);

import { getSECURE_API, API, baseURL, TOKEN_KEY } from 'api';
import { toast } from 'react-toastify';

const SECURE_API = getSECURE_API();
SECURE_API.interceptors.request.use((req) => {
  req.baseURL = `${req.baseURL}/events`;
  return req;
});

// API.interceptors.request.use((req) => {
//   req.baseURL = `${req.baseURL}/users`;
//   return req;
// });

export const getAll = () => SECURE_API.get('/');
export const createOne = (event) => {
  const formData = new FormData();
  for (const [key, value] of Object.entries(event)) {
    console.log(`${key}: ${value}`);
    formData.append(key, value);
  }
  formData.delete('users');

  return fetch(`${baseURL}/events`, {
    body: formData,
    method: 'POST',
    headers: {
      Authorization: `Bearer ${localStorage.getItem(TOKEN_KEY)}`,
    },
  }).then(async (res) => {
    if (res.ok) return await res.json();
    else return Promise.reject(res.error);
    // callBack?.();
  });
};

export const handleBooking = ({ id, updatedEvent }) =>
  SECURE_API.patch(`/${id}/handleBooking`, {
    ...updatedEvent,
  });

export const deleteOne = (id) => SECURE_API.delete(`/${id}`);
export const registerEvent = (id, updatedEvent) =>
  SECURE_API.post(`/${id}/bookings`);

export const cancelEvent = (id, updatedEvent) =>
  SECURE_API.delete(`/${id}/bookings`);

export const updateOne = (id, updatedEvent) => {
  const formData = new FormData();
  for (const [key, value] of Object.entries(updatedEvent)) {
    console.log(`${key}: ${value}`);
    formData.append(key, value);
  }

  formData.delete('users');

  return fetch(`${baseURL}/events/${id}`, {
    body: formData,
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${localStorage.getItem(TOKEN_KEY)}`,
    },
  }).then(async (res) => {
    if (res.ok) return await res.json();
    else return Promise.reject(res.error);
    // callBack?.();
  });
};

export const updateStatus = (id, status) =>
  SECURE_API.patch(`/${id}/status`, {
    status,
  });

import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Navigate, Route, Routes } from 'react-router-dom';
import Home from './components/home';
import Main from 'components/auth/Main';
import DashboardLayout from 'layouts/dashboard';
import Users from 'components/dashboard/user';
import Events from 'components/dashboard/events';
import NewEvent from 'components/dashboard/events/newEvent';
import { logout } from 'store/slices/auth';
import Footer from 'components/footer/footer';
import HomePageLayout from 'layouts/HomePageLayout';
import Loading from 'components/Loading';
import Profile from 'components/profile';
import Messages from 'components/dashboard/messages';
import UpdateEvent from 'components/dashboard/events/updateEvent';
import DashboardApp from 'components/dashboard/DashboardApp';
import ForgotPass from 'components/auth/ForgotPass';
import ResetPass from 'components/auth/ResetPass';

const Logout = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(logout());
  }, []);

  return <></>;
};

const Router = () => {
  const { isLoggedIn, authenticating } = useSelector((st) => st.auth);

  return (
    <div>
      {!authenticating ? (
        <Routes>
          <Route path='' element={<HomePageLayout element={<Home />} />} />
          <Route
            path='account'
            element={<HomePageLayout element={<Main />} />}
          />
          <Route path='*' element={<Navigate to='/' />} />
          <Route exact path='/forgot' element={<ForgotPass />} />
          <Route
            exact
            path='/resetPassword/:resetToken'
            element={<ResetPass />}
          />

          {isLoggedIn ? (
            <Route>
              <Route path='/dashboard' element={<DashboardLayout />}>
                <Route path='' element={<DashboardApp />} />
                <Route path='profile' element={<Profile />} />
                <Route path='users' element={<Users />} />
                <Route path='messages' element={<Messages />} />
                <Route path='events' element={<Events />} />
                <Route path='events/:id' element={<UpdateEvent />} />
                <Route path='events/new' element={<NewEvent />} />
              </Route>
              <Route path='/logout' element={<Logout />} />
            </Route>
          ) : (
            <Route> </Route>
          )}
        </Routes>
      ) : (
        <Loading />
      )}
    </div>
  );
};

export default Router;
